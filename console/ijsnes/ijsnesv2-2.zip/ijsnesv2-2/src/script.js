// iJSNES - v2.0
// Emulator - JSNES (jsnes.org)
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Features:
//  - Touch UI     - Touch Screen Zapper
//  - Save State   - Turbo Buttons
//  - Hold Buttons - Slow Button
//  - Menu System  - Pause
//
// BUTTON Interval - NES Advantage Details
// Turbo: 15Hz to 30Hz? (source: jsnes github forum)
// Slow: ??
// 15Hz = 0.0666667 / sec <--> 66 thousands / sec?
// 30Hz = 0.0333333 / sec <--> 33 thousands / sec?
//

function setButtonInterval(id) {
  var s = document.getElementById(id);
  var l = document.getElementById($(s).attr('led'));
  var b = document.getElementById($(s).attr('button'));
  var i = document.getElementById($(s).attr('input'));
  var player = 1;
  
  if (id == 'slider_a') {
    nesButton = jsnes.Controller.BUTTON_A;
    clearInterval(window.intervalId_A);
    window.intervalId_A = setInterval(function () {
      if ($(s).attr('status') == 'on') {
        if ($(b).attr('status') == 'up') {
          nes.buttonDown(player, nesButton);
          l.style.backgroundColor = '#f00';
          $(b).attr('status','down');
        } else {
          nes.buttonUp(player, nesButton);
          l.style.backgroundColor = '#500';
          $(b).attr('status','up');
        }
      } else {
        $(i).attr('value','0');
        $(b).attr('status','up');
        clearInterval(window.intervalId_A);
      }
    }, 1000-($(i).attr('value'))*10);  //interval
  }
  if (id == 'slider_b') {
    nesButton = jsnes.Controller.BUTTON_B;
    clearInterval(window.intervalId_B);
    window.intervalId_B = setInterval(function () {
      if ($(s).attr('status') == 'on') {
        if ($(b).attr('status') == 'up') {
          nes.buttonDown(player, nesButton);
          l.style.backgroundColor = '#f00';
          $(b).attr('status','down');
        } else {
          nes.buttonUp(player, nesButton);
          l.style.backgroundColor = '#500';
          $(b).attr('status','up');
        }
      } else {
        $(i).attr('value','0');
        $(b).attr('status','up');
        clearInterval(window.intervalId_B);
      }
    }, 1000-($(i).attr('value'))*20);  //interval
  }
}

function knob(id,winY) {
  var s = document.getElementById(id),
    knb = $(s).attr('knob'),
    min = $(s).attr('min'),
    ttl = ($(s).attr('title'));
  var l = document.getElementById($(s).attr('led'));
  var o = document.getElementById($(s).attr('output'));
  var i = document.getElementById($(s).attr('input')),   
    stp = parseFloat(i.step),
    val = parseFloat(i.value),
    str = ($(i).attr("start")),
    lst = ($(i).attr("last")),
    fls = i.parentElement,
    per = i.value;
//  player = 1;
//  if (id == 'slider_a') {
//    $('#output_a').attr('data-before','A');
//    nesButton = jsnes.Controller.BUTTON_A;
//  }
//  if (id == 'slider_b') {
//    $('#output_b').attr('data-before','B');
//    nesButton = jsnes.Controller.BUTTON_B;
//  }
  
  function plot() {
    if ($(s).attr('status')=='off') return;
    if (per >= 0 && per <= 100) deg = per*1.32*2; 
    fls.style.transform = 'rotate(' + deg + 'deg)';
    $(i).attr('value', Math.floor(per));
    $(o).attr('data-before', Math.floor(per)+ttl);
  }

  var curDiff = winY - str;
  var diff = curDiff - lst;
  if (diff > 0) i.stepDown();
  if (diff < 0) i.stepUp();
  $(i).attr('last',curDiff);
  
  plot();
};

// TURBO Switches //
function slider(id) {
  var s = document.getElementById(id),
      i = document.getElementById($(s).attr('input')),
      o = document.getElementById($(s).attr('output')),
      l = document.getElementById($(s).attr('led')),
      b = document.getElementById($(s).attr('button')),
    knb = $(s).attr('knob'),
    min = $(s).attr('min'),
    ttl = $(s).attr('title'),
 player = 1;
  if (id == 'slider_a') {
    nesButton = jsnes.Controller.BUTTON_A;
  }
  if (id == 'slider_b') {
    nesButton = jsnes.Controller.BUTTON_B;
  }
  if ($(s).status=='init') {
    s.style.setProperty('--position','25%');
    s.style.setProperty('--background','#ddd');
    $(s).attr('status','off');
    $(o).attr('data-before',ttl);
  } else if ($(s).attr('status')=='off') {
    s.style.backgroundColor = '#ddd';
    s.style.setProperty('--position','50%');
    s.style.setProperty('--background','#888');
    $(s).attr('status','on');
    $(knb).show();
    $(min).show();
  } else if ($(s).attr('status')=='on') {
    s.style.backgroundColor = '#ddd';
    s.style.setProperty('--position','75%');
    s.style.setProperty('--background','#888');
    $(s).attr('status','hold');
    nes.buttonDown(player, nesButton);
    l.style.backgroundColor = '#f00';
    $(o).attr('data-before','hold   '+ttl);
    $(knb).hide();
    $(min).hide();
  } else {
    s.style.backgroundColor = '#888';
    s.style.setProperty('--position','25%');
    s.style.setProperty('--background','#ddd');
    l.style.backgroundColor = '#500';
    $(s).attr('status','off');
    nes.buttonUp(player, nesButton);
    $(knb).hide();
    $(min).hide();
    $(i).val('0');
    $(o).attr('data-before',ttl);
  }

//  if ($(knb).is(':visible') || dir=='off') {
//    s.style.backgroundColor = '#888';
//    s.style.setProperty('--position','25%');
//    s.style.setProperty('--background','#ddd');
//    $(s).attr('status','off');
//    $(knb).hide();
//    $(min).hide();
//    $(i).val('0');
//    $(o).attr('data-before',ttl);
//    return;
//  } else {
//    s.style.backgroundColor = '#ddd';
//    s.style.setProperty('--position','50%');
//    s.style.setProperty('--background','#888');
//    $(s).attr('status','on');
//    $(knb).show();
//    $(min).show();
//  }
}

// GLOBAL START //
function start() {
  frameTimer.start();
  this.speakers.start();
}

// GLOBAL STOP //
function stop() {
  frameTimer.stop(); 
  this.speakers.stop();
}

// TOUCH CONTROLS //
var joypadWidth = 256,
    joypadHeight = 256;
var I1 = 0, I2 = 0,
     A = 0,  B = 0;
var joypadX = joypadWidth  / 2,
    joypadY = joypadHeight / 2,
    zapperX = 0,
    zapperY = 0;
var X1 = joypadWidth  / 2,
    Y1 = joypadHeight / 2,
    X2 = joypadWidth  / 2,
    Y2 = joypadHeight / 2;
var player = 1;
var slowStatus = 'off';
var touchZones = [
  '#selectButton_h, #selectButton_v',
  '#loadButton_h, #loadButton_v',
  '#startButton_h, #startButton_v',
  '#joyPad_h, #joyPad_v',
  '#joyButton_a', '#joyButton_b',
  '#joyButtons_v',
  '#menuButton_h, #menuButton_v',
  '#resume',
  '#stateButtonSave', '#stateButtonLoad',
  '#slowButton', '#slide_a', '#slide_b',
  '#left_frame', '#right_frame'
];
touchZones.forEach(function (selector) {
  var zone = touchZones.indexOf(selector);
  $(selector).bind('touchstart', function (e) {
    // TOUCH START
    e.preventDefault();
    switch (zone) {
      case 0: // Select Press
        nes.buttonDown(player, jsnes.Controller.BUTTON_SELECT);
      break;
      case 2: // Start Press
        nes.buttonDown(player, jsnes.Controller.BUTTON_START);
      break;
      case 3: // JoyPad Press
        if (I1 == 0) I1 = e.touches.length;
        getPos(e, e.target, I1);
        X1 = X; Y1 = Y;
        setDpad(player, X1, Y1);
      break;
      case 4: // JoyButton A Press
        if ($('#slider_a').attr('status')=='on') {
          if (I2 == 0) I2 = e.touches.length;
          WY = Math.round(e.touches[I2 - 1].pageY);
          $('slide_a').attr('start', WY);
        } else {
        nes.buttonDown(player,jsnes.Controller.BUTTON_A);
          led_a.style.backgroundColor = '#f00';
        }
      break;
      case 5: // JoyButton B Press
        if ($('#slider_b').attr('status')=='on') {
          if (I2 == 0) I2 = e.touches.length;
          WY = Math.round(e.touches[I2 - 1].pageY);
          $('#slider_b').attr('start', WY);
        } else {
        nes.buttonDown(player,jsnes.Controller.BUTTON_B);
          led_b.style.backgroundColor = '#f00';
        }
      break;
      default: break;
    }
  // TOUCH MOVE
  }).bind('touchmove', function (e) {
      e.preventDefault();
      switch (zone) {
        case 3: // JoyPad Move
          if (I1 > e.touches.length) {
            I1 = Math.max(0, I1 - 1);
          }
          getPos(e, e.target, I1);
          X1 = X; Y1 = Y;
          setDpad(player, X1, Y1);
        break;
        
        case 4: // JoyButton A Move
          if ($('#slider_a').attr('status')=='on') {
            if (I2 == 0) I2 = e.touches.length;
            WY = Math.round(e.touches[I2 - 1].pageY);
            knob('slider_a', WY);
          }
        break;
        
        case 5: // JoyButton B Move
          if ($('#slider_b').attr('status')=='on') {
            if (I2 == 0) I2 = e.touches.length;
            WY = Math.round(e.touches[I2 - 1].pageY);
            knob('slider_b', WY);
          }
        break;
          
        default: break;
      }
    }) // TOUCH END
    .bind('touchend', function (e) {
    e.preventDefault();
    switch (zone) {
      case 0: // Select Release
        nes.buttonUp(player, jsnes.Controller.BUTTON_SELECT);
      break;
      case 1: // Load Rom
        $('#rom').trigger('click');
      break;
      case 2: // Start Release
      nes.buttonUp(player,jsnes.Controller.BUTTON_START);
      break;
      case 3: // JoyPad Release
        I1 = 0;
        X1 = joypadWidth / 2;
        Y1 = joypadHeight / 2;
        nes.buttonUp(player,jsnes.Controller.BUTTON_UP);
       nes.buttonUp(player,jsnes.Controller.BUTTON_DOWN);
       nes.buttonUp(player,jsnes.Controller.BUTTON_LEFT);
      nes.buttonUp(player,jsnes.Controller.BUTTON_RIGHT);
      break;
      case 4: // JoyButton Release
        if($('#slider_a').attr('status')=='hold') return; 
        if($('#slider_a').attr('status')=='on') {
          clearInterval(window.intervalId_A);   
          setButtonInterval('slider_a');
        }
        nes.buttonUp(player,jsnes.Controller.BUTTON_A);
        led_a.style.backgroundColor = '#500';
        I2 = 0;
      break;
      case 5:
        if($('#slider_b').attr('status')=='hold') return; 
        if($('#slider_b').attr('status')=='on') {
          clearInterval(window.intervalId_B);
          setButtonInterval('slider_b');
        }     
        nes.buttonUp(player,jsnes.Controller.BUTTON_B);
        led_b.style.backgroundColor = '#500';
        I2 = 0;
      break;
      case 7: // Menu (pause)
        if($('#menu_h').attr('status')=='on') {
          $('#menu').hide();
          start();
          $('#menu_h').attr('status', 'off');
        } else {
          $('#menu').show();
          stop();
          $('#menu_h').attr('status', 'on');
        }
      break;
      case 8: // Resume
        $('#menu_h').attr('status', 'off');
        composeScreen();
        start();
      break;
      case 9: // State Save
        saveState();
      break;
      case 10: // State Load
        loadState();
      break;
      case 11: // Button Slow (start)
        var button = jsnes.Controller.BUTTON_START;
        if($(this).attr('data-text')=='on') {
          $(this).attr('state', '0');
          $(this).attr('data-text', 'off');
        } else {
          $(this).attr('state', '1');
          $(this).attr('data-text', 'on');
//           setButtonInterval (player, this, "led_start", button, 66);
        }
      break;
      case 12: // Turbo Switch A
        slider('slider_a');
        if ($('#slider_a').attr('status')=='on') {
          clearInterval(window.intervalId_A);
          setButtonInterval('slider_a');
          knob('slider_a', 0);
        }
      break;
      case 13: // Turbo Switch B
        slider('slider_b'); 
        if ($('#slider_b').attr('status')=='on') {
          clearInterval(window.intervalId_B); 
          setButtonInterval('slider_b');
          knob('slider_b', 0);
        }
      break;
      default: break;
    }
  })
});

// TOUCH ZAPPER //
const screen = document.getElementById('screen');
screen.addEventListener(
  'mousedown',
  function (e) {
    var rect = screen.getBoundingClientRect();
    var zapperX = Math.round(
      ((e.clientX - rect.left) / (rect.right - rect.left)) * screen.width
    );
    var zapperY = Math.round(
      ((e.clientY - rect.top) / (rect.bottom - rect.top)) * screen.height
    );
    nes.zapperMove(zapperX, zapperY);
  },
  false
);
screen.addEventListener('touchstart', function () {
  nes.zapperFireDown();
});
screen.addEventListener('touchend', function () {
  nes.zapperFireUp();
});

// GET TOUCH POSITION //
function getPos(e, element, ind) {
  var rect = e.target.getBoundingClientRect();
  X = Math.round(
    ((e.touches[ind - 1].clientX - rect.left) / (rect.right - rect.left)) *
    e.target.width
  );
  Y = Math.round(
    ((e.touches[ind - 1].clientY - rect.top) / (rect.bottom - rect.top)) *
    e.target.height
  );
  WY = Math.round(e.touches[ind - 1].pageY);
  return X, Y, WY;
}

// SET TOUCH DPAD STATUS //
function setDpad(player, joypadX, joypadY) {
  var Z = 3;
  if (joypadX < 110 || joypadX > 146 || joypadY < 110 || joypadY > 146) {
    if (
      joypadY < joypadHeight / Z ||
      (joypadX > joypadY && joypadY < 256 - joypadX)
    ) {
      nes.buttonDown(player, jsnes.Controller.BUTTON_UP);
    } else {
      nes.buttonUp(player, jsnes.Controller.BUTTON_UP);
    } // UP
    if (
      joypadY > (joypadHeight / Z) * (Z - 1) ||
      (joypadX < joypadY && joypadY > 256 - joypadX)
    ) {
      nes.buttonDown(player, jsnes.Controller.BUTTON_DOWN);
    } else {
      nes.buttonUp(player, jsnes.Controller.BUTTON_DOWN);
    } // DOWN
    if (
      joypadX < joypadWidth / Z ||
      (joypadX < joypadY && joypadY < 256 - joypadX)
    ) {
      nes.buttonDown(player, jsnes.Controller.BUTTON_LEFT);
    } else {
      nes.buttonUp(player, jsnes.Controller.BUTTON_LEFT);
    } // LEFT
    if (
      joypadX > (joypadWidth / Z) * (Z - 1) ||
      (joypadX > joypadY && joypadY > 256 - joypadX)
    ) {
      nes.buttonDown(player, jsnes.Controller.BUTTON_RIGHT);
    } else {
      nes.buttonUp(player, jsnes.Controller.BUTTON_RIGHT);
    } // RIGHT
  }
}

// KEYBOARD CONTROLS //
document.addEventListener("keydown", (event) => {
  keyboard(nes.buttonDown, event);
});
document.addEventListener("keyup", (event) => {
  keyboard(nes.buttonUp, event);
});

function keyboard(callback, event) {
  var player = 1;
  switch (event.keyCode) {
    case 49: // Load
      $("#rom").trigger("click");
      break;
    case 38: // UP
      callback(player, jsnes.Controller.BUTTON_UP);
      break;
    case 40: // Down
      callback(player, jsnes.Controller.BUTTON_DOWN);
      break;
    case 37: // Left
      callback(player, jsnes.Controller.BUTTON_LEFT);
      break;
    case 39: // Right
      callback(player, jsnes.Controller.BUTTON_RIGHT);
      break;
    case 65: // 'a' - qwerty, dvorak
    case 81: // 'q' - azerty
      callback(player, jsnes.Controller.BUTTON_A);
      break;
    case 83: // 's' - qwerty, azerty
    case 79: // 'o' - dvorak
      callback(player, jsnes.Controller.BUTTON_B);
      break;
    case 9: // Tab
      callback(player, jsnes.Controller.BUTTON_SELECT);
      break;
    case 13: // Return
      callback(player, jsnes.Controller.BUTTON_START);
      break;
    default: break;
  }
}

// COMPOSE SCREEN //
function composeScreen() {
  var height = ($(window).height());
  var width = $(window).width();
  let displayRatio = 256 / 240;
  let controlsRatio = 375 / 150;
  let screenWidth = height * displayRatio;
  let screenHeight = height - 2;
  if (width > height) {
    $("#controls_h").show();
    $("#controls_v").hide();
    $("#menu").hide();
    if ($('#slider_a').attr('status')=='init') {
      slider('slider_a'); }
    if ($('#slider_b').attr('status')=='init') {
      slider('slider_b');
    }
    if (screenWidth > width * 0.6) {
      screenWidth = width * 0.7;
      screenHeight = screenWidth / displayRatio;
    }
    screen.style.width = screenWidth + "px";
    screen.style.height = screenHeight + "px";
    screen.style.top = "50%";
    left_frame.style.left = (width - screenWidth) / 4 + "px";
    right_frame.style.right = (width - screenWidth) / 4 + "px";
    if ((width - screenWidth) / 2 < width/4) {
      left_frame.style.width = (width - screenWidth) / 2 + "px";
      right_frame.style.width = (width - screenWidth) / 2 + "px";
    } else {
      left_frame.style.width = "24.8%";
      right_frame.style.width = "24.8%";
    }
  } else {
    $("#controls_h").hide();
    $("#controls_v").show();
    $("#menu").hide();
    $(".min").hide();
    $(".knob").hide();
    this.controls = document.getElementById("controls_v");
    screen.style.height = window.innerWidth / displayRatio + "px";
    screen.style.width = width-2 + "px";
    if (width / displayRatio > height - width / controlsRatio) {
      screen.style.top = width / displayRatio / 2 + "px";
    } else {
      screen.style.top = (height - width / controlsRatio) / 2 + "px";
    }
    this.controls.style.height = Math.round(width / controlsRatio) + "px";
    this.controls.style.width = width + "px";
    if (width / controlsRatio + width / displayRatio > height) {
      this.controls.style.opacity = 0.5;
    }
  }
}

// JSNES STATE/FILE SETUP AND CONFIG //
//prefixes of implementation that we want to test
window.indexedDB = window.indexedDB || window.mozIndexedDB || window.webkitIndexedDB || window.msIndexedDB;

//prefixes of window.IDB objects
window.IDBTransaction = window.IDBTransaction || window.webkitIDBTransaction || window.msIDBTransaction;
window.IDBKeyRange = window.IDBKeyRange || window.webkitIDBKeyRange || window.msIDBKeyRange;

const romData = [
  {
    rom: "test",
    data: 0
  }
];

var db;
var request = window.indexedDB.open("iJSNESDB", 1);

request.onsuccess = function () {
  db = request.result;
};

request.onupgradeneeded = function (e) {
  var db = e.target.result;
  var objectStore = db.createObjectStore("romSave", {
    keyPath: "rom"
  });
  for (var J in romData) {
    objectStore.add(romData[J]);
  }
};

// SAVE STATE DB Save
function saveState() {
  var romName = escape(nes.currentRom);
  var saveName = escape(nes.currentRom) + ".sav";
  var saveData = JSON.stringify(nes.toJSON());
  var request = db
    .transaction(["romSave"], "readwrite")
    .objectStore("romSave")
    .add({
      rom: romName,
      data: saveData
    });
  request.onsuccess = function (event) {};
  request.onerror = function (event) {
    var request = db
      .transaction(["romSave"], "readwrite")
      .objectStore("romSave")
      .put({
        rom: romName,
        data: saveData
    });
  }
}

// STATE DB Load
function loadState() {
  var objectStore = db.transaction("romSave").objectStore("romSave");
  objectStore.openCursor().onsuccess = function (event) {
    var cursor = event.target.result;
    if (cursor) {
      if (cursor.value.rom === escape(nes.currentRom)) {
        var saveData = cursor.value.data;
        var decodedData = JSON.parse(saveData);
        nes.fromJSON(decodedData);
        frameTimer.generateFrame();
        frameTimer.onWriteFrame();
        stop();
      }
      cursor.continue();
    }
  }
}

// SAVE STATE File Save
function saveFile() {
  var romName = escape(nes.currentRom);
  var saveName = escape(nes.currentRom) + ".sav";
  var saveData = JSON.stringify(nes.toJSON());
  var blob = new Blob([saveData], {
    type: "text/plain;charset=utf-8"
  });
  var evt = document.createElement("a");
  evt.href = "data:text/json;," + saveData;
  evt.download = saveName;
  evt.click();
  document.body.removeChild(evt);
}

// LOAD STATE File Load
function loadFile(input) {
  file = input.files[0];
  var blob = new Blob([file], {
    type: "text/plain;charset=utf-8"
  });
  fr = new FileReader();
  fr.onload = function () {
    var saveData = fr.result;
    // var decodedData = JSON.parse(saveData);
    nes.fromJSON(saveData);
    // window.requestAnimationFrame(onAnimationFrame);
  };
  fr.readAsBinaryString(blob);
}

// ROM Loading
function getROM(input) {
  file = input.files[0];
  nes.currentRom = file.name;
  fr = new FileReader();
  fr.onload = function () {
    var rom_data = fr.result;
    nes.loadROM(rom_data);
    start();
  };
  fr.readAsBinaryString(file);
}

  

  
  
// JSNES DISPLAY SETUP AND CONFIG //
// Define JSNES instance
const SCREEN_WIDTH = 256;
const SCREEN_HEIGHT = 240;
const FPS = 60.098;
var framebuffer_size = SCREEN_WIDTH * SCREEN_HEIGHT,
    buf8,
    buf32;

// JSNES AUDIO SETUP AND CONFIG //
class speakers {
  constructor({ onBufferUnderrun }) {
    this.onBufferUnderrun = onBufferUnderrun;
    this.bufferSize = 8192;
    this.buffer = new RingBuffer(this.bufferSize * 2);
  }
  
  start() {
    this.audioCtx = new window.AudioContext();
    this.scriptNode = this.audioCtx.createScriptProcessor(1024, 0, 2);
    this.scriptNode.onaudioprocess = this.onaudioprocess;
    this.scriptNode.connect(this.audioCtx.destination);
  }
  
  stop() {
    if (this.script_processor) {
      this.script_processor.disconnect(this.audioCtx.destination);
      this.script_processor.onaudioprocess = null;
      this.script_processor = null;
    }
    if (this.audioCtx) {
      this.audioCtx.close();
      this.audioCtx = null;
    }
  }
  
  writeSample = (left, right) => {
    if (this.buffer.size() / 2 >= this.bufferSize) {
      this.buffer.deqN(this.bufferSize / 2);
    }
    this.buffer.enq(left);
    this.buffer.enq(right);
  }

  onaudioprocess = e => {
    var left = e.outputBuffer.getChannelData(0);
    var right = e.outputBuffer.getChannelData(1);
    var size = left.length;
    
    if (this.buffer.size() < size * 2 && this.onBufferUnderrun) {
      this.onBufferUnderrun(this.buffer.size(), size*2);
    }

    try {
      var samples = this.buffer.deqN(size * 2);
    } catch (e) {
      var bufferSize = this.buffer.size() / 2;
      for (var j = 0; j < size; j++) {
        left[j] = 0;
        right[j] = 0;
      }
      return;
    }
    for (var i = 0; i < size; i++) {
      left[i] = samples[i * 2];
      right[i] = samples[i * 2 + 1];
    }
  }
}

this.speakers = new speakers({
  onBufferUnderrun: (actualSize, desiredSize) => {
    if ($("#menu").attr("data-text")==="on") { return; }
    this.frameTimer.generateFrame();
    if (this.speakers.buffer.size() < desiredSize) {
      this.frameTimer.generateFrame();
    }
  }
});

var nes = new jsnes.NES({
  onFrame: this.setBuffer,
  onAudioSample: this.speakers.writeSample
});

function nes_init(canvas_id) {
  this.canvas = document.getElementById(canvas_id);
  this.context = this.canvas.getContext("2d");
  this.imageData = this.context.getImageData(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
  this.context.fillStyle = "black";
  
// set alpha to opaque
  this.context.fillRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);

// buffer to write on next animation frame
  this.buf = new ArrayBuffer(this.imageData.data.length);
    
// Get the canvas buffer in 8bit and 32bit
  this.buf8 = new Uint8ClampedArray(this.buf);
  this.buf32 = new Uint32Array(this.buf);
  
// Set alpha
  for (var i = 0; i < this.buf32.length; ++i) {
    this.buf32[i] = 0xff000000;
  }
}

function setBuffer(buffer) {
  var i = 0;
  for (var y = 0; y < SCREEN_HEIGHT; ++y) {
    for (var x = 0; x < SCREEN_WIDTH; ++x) {
      i = y * 256 + x;
      // Convert pixel from NES BGR to canvas ABGR
      buf32[i] = 0xff000000 | buffer[i]; // Full alpha
    }
  }
}

function writeBuffer() {
  imageData.data.set(buf8);
  context.putImageData(imageData, 0, 0);
};

// FRAME TIMING //
class FrameTimer {
  constructor(props) {
    // Run at 60 FPS
    this.onGenerateFrame = props.onGenerateFrame;
    // Run on animation frame
    this.onWriteFrame = props.onWriteFrame;
    this.onAnimationFrame = this.onAnimationFrame.bind(this);
    this.interval = 1e3 / FPS;
    this.lastFrameTime = false;
  }
  
  start() {
    this.requestAnimationFrame();
  }

  stop() {
    if (this._requestID) window.cancelAnimationFrame(this._requestID);
    this.lastFrameTime = false;
  }

  requestAnimationFrame() {
    this._requestID = window.requestAnimationFrame(this.onAnimationFrame);
  }

  generateFrame() {
    this.onGenerateFrame();
    this.lastFrameTime += this.interval;
  }

  onAnimationFrame = time => {
    this.requestAnimationFrame();
    // how many ms after 60fps frame time
    let excess = time % this.interval;
    // newFrameTime is the current time aligned to 60fps intervals.
    // i.e. 16.6, 33.3, etc ...
    let newFrameTime = time - excess;

    // first frame, do nothing
    if (!this.lastFrameTime) {
      this.lastFrameTime = newFrameTime;
      return;
    }

    let numFrames = Math.round(
      (newFrameTime - this.lastFrameTime) / this.interval
    );

    // This can happen a lot on a 144Hz display
    if (numFrames === 0) {
      return;
    }

    // update screen on first frame only
    this.generateFrame();
    this.onWriteFrame();

    // we generate additional frames evenly before the next
    // onAnimationFrame call.
    // additional frames are generated but not displayed
    // until next frame draw
    let timeToNextFrame = this.interval - excess;
    for (let i = 1; i < numFrames; i++) {
      setTimeout(() => {
        this.generateFrame();
      }, (i * timeToNextFrame) / numFrames);
    }
    if (numFrames > 1) console.log("SKIP", numFrames - 1, this.lastFrameTime);
  };
}

this.frameTimer = new FrameTimer({
  onGenerateFrame: this.nes.frame,
  onWriteFrame: this.writeBuffer
});

// INITIAL LAYOUT //
document.addEventListener("load", function () {
  composeScreen();
});
$(window).on("resize", function () {
  composeScreen();
});
composeScreen();
nes_init("screen");

// RINGBUFFER MODULE //
function RingBuffer(capacity, evictedCb) {
  this._elements = new Array(capacity || 50);
  this._first = 0;
  this._last = 0;
  this._size = 0;
  this._evictedCb = evictedCb;
}
RingBuffer.prototype.capacity = function() {  
  return this._elements.length;
};
RingBuffer.prototype.isEmpty = function() {
  return this.size() === 0;
};
RingBuffer.prototype.isFull = function() {
    return this.size() === this.capacity();
};
RingBuffer.prototype.peek = function() {
  if (this.isEmpty()) throw new Error('RingBuffer is empty');
  return this._elements[this._first];
};
RingBuffer.prototype.peekN = function(count) {
  if (count > this._size) throw new Error('Not enough elements in RingBuffer');
  var end = Math.min(this._first + count, this.capacity());
  var firstHalf = this._elements.slice(this._first, end);
  if (end < this.capacity()) {
    return firstHalf;
  }
  var secondHalf = this._elements.slice(0, count - firstHalf.length);
  return firstHalf.concat(secondHalf);
};
RingBuffer.prototype.deq = function() {
  var element = this.peek();
  this._size--;
  this._first = (this._first + 1) % this.capacity();
  return element;
};
RingBuffer.prototype.deqN = function(count) {
  var elements = this.peekN(count);
  this._size -= count;
  this._first = (this._first + count) % this.capacity();
  return elements;
};
RingBuffer.prototype.enq = function(element) {
  this._end = (this._first + this.size()) % this.capacity();
  var full = this.isFull()
  if (full && this._evictedCb) {
    this._evictedCb(this._elements[this._end]);
  }
  this._elements[this._end] = element;
  if (full) {
    this._first = (this._first + 1) % this.capacity();
  } else {
    this._size++;
  }
  return this.size();
};
RingBuffer.prototype.size = function() {
  return this._size;
};