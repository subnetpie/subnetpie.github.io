//===========================================================
// Scramble Emulator — MAME-faithful
//===========================================================
// ── PPI 8255 ─────────────────────────────────────────────
// i8255.cpp: mode-0 I/O with bit-set/reset on control port.
class PPI8255 {
 constructor(
  portARead,
  portBRead,
  portCRead,
  portAWrite,
  portBWrite,
  portCWrite
 ) 
 {
  this.portARead = portARead ?? (() => 0xff);
  this.portBRead = portBRead ?? (() => 0xff);
  this.portCRead = portCRead ?? (() => 0xff);
  this.portAWrite = portAWrite ?? (() => {});
  this.portBWrite = portBWrite ?? (() => {});
  this.portCWrite = portCWrite ?? (() => {});
  this.control = 0x9b;
  this.latchA = 0;
  this.latchB = 0;
  this.latchC = 0;
 }

 read(offset) {
  switch (offset & 3) {
   case 0:
    return this.control & 0x10 ? this.portARead() & 0xff : this.latchA;
   case 1:
    return this.control & 0x02 ? this.portBRead() & 0xff : this.latchB;
   case 2: {
    const pc = this.portCRead() & 0xff;
    let v = 0;
    v |= this.control & 0x08 ? pc & 0xf0 : this.latchC & 0xf0;
    v |= this.control & 0x01 ? pc & 0x0f : this.latchC & 0x0f;
    return v;
   }
   case 3:
    return this.control;
  }
  return 0xff;
 }

 write(offset, data) {
  data &= 0xff;
  switch (offset & 3) {
   case 0:
    this.latchA = data;
    if (!(this.control & 0x10)) this.portAWrite(data);
    break;
   case 1:
    this.latchB = data;
    if (!(this.control & 0x02)) this.portBWrite(data);
    break;
   case 2:
    this.latchC = data;
    if (!(this.control & 0x08)) this.portCWrite(data & 0xf0);
    if (!(this.control & 0x01)) this.portCWrite(data & 0x0f);
    break;
   case 3:
    if (data & 0x80) {
     this.control = data;
     this.latchA = this.latchB = this.latchC = 0;
    } else {
     const bit = (data >> 1) & 0x07;
     if (data & 1) this.latchC |= 1 << bit;
     else this.latchC &= ~(1 << bit);
     if (!(this.control & 0x08) && bit >= 4)
      this.portCWrite(this.latchC & 0xf0);
     if (!(this.control & 0x01) && bit < 4) this.portCWrite(this.latchC & 0x0f);
    }
    break;
  }
 }
}

// ── AY-8910 ──────────────────────────────────────────────
class AY8910 {
 // AY-8910 amplitude table (hardware uses ~3dB steps per level)
 static VOLUME_TABLE = (() => {
  const t = new Float32Array(16);
  for (let i = 1; i < 16; i++) t[i] = Math.pow(10, ((i - 15) * 3) / 20);
  return t;
 })();

 // Envelope shapes: 10 defined shapes, indexed by regs[0x0D] & 0x0F
 // Each shape is an array of 32 amplitude values (0–15)
 static ENVELOPE_SHAPES = (() => {
  const shapes = [];
  const make = (fn) => {
   const s = new Uint8Array(32);
   for (let i = 0; i < 32; i++) s[i] = fn(i);
   return s;
  };
  const up = (i) => (i < 16 ? i : 15);
  const down = (i) => (i < 16 ? 15 - i : 0);
  const hold_hi = (i) => 15;
  const hold_lo = (i) => 0;
  const tri_up = (i) => (i < 16 ? i : 15 - (i - 16));
  const tri_dn = (i) => (i < 16 ? 15 - i : i - 16);
  // shapes 0-3: decay, hold low
  for (let i = 0; i < 4; i++) shapes.push(make(down));
  // shapes 4-7: attack, hold low
  for (let i = 0; i < 4; i++) shapes.push(make(up));
  // shape 8: saw down (repeat decay)
  shapes.push(make((i) => 15 - (i % 16)));
  // shape 9: decay, hold low
  shapes.push(make(down));
  // shape A: triangle down
  shapes.push(
   make((i) => {
    const p = i % 32;
    return p < 16 ? 15 - p : p - 16;
   })
  );
  // shape B: decay, hold high
  shapes.push(make((i) => (i < 16 ? 15 - i : 15)));
  // shape C: saw up (repeat attack)
  shapes.push(make((i) => i % 16));
  // shape D: attack, hold high
  shapes.push(make((i) => (i < 16 ? i : 15)));
  // shape E: triangle up
  shapes.push(
   make((i) => {
    const p = i % 32;
    return p < 16 ? p : 31 - p;
   })
  );
  // shape F: attack, hold low
  shapes.push(make(up));
  return shapes;
 })();

 constructor(
  audioCtx,
  clock = 1_789_750,
  portARead = null,
  portBRead = null,
  portAWrite = null,
  portBWrite = null
 ) {
  this.clock = clock;
  this.regs = new Uint8Array(16);
  this.addrLatch = 0;
  this.portARead = portARead;
  this.portBRead = portBRead;
  this.portAWrite = portAWrite;
  this.portBWrite = portBWrite;
  this.ctx = audioCtx;
  this.channels = [];

  // Envelope state
  this._envPhase = 0; // 0–31 current step within shape
  this._envClock = 0; // accumulated envelope period clocks
  this._envTrigger = false;

  // Noise state (LFSR — only used for amplitude gating)
  this._noiseClock = 0;
  this._noiseBit = 1;
  this._noiseShift = 1;

  if (!audioCtx) return;

  this.masterGain = audioCtx.createGain();
  this.masterGain.gain.value = 0.15;
  this.masterGain.connect(audioCtx.destination);

  this.channels = Array.from({ length: 3 }, () => {
   const osc = audioCtx.createOscillator();
   const gain = audioCtx.createGain();
   osc.type = "square";
   osc.frequency.value = 440;
   gain.gain.value = 0;
   osc.connect(gain);
   gain.connect(this.masterGain);
   osc.start();
   return { osc, gain };
  });
 }

 writeAddr(val) {
  this.addrLatch = val & 0x0f;
 }

 writeData(val) {
  const r = this.addrLatch;
  this.regs[r] = val & 0xff;

  // Envelope trigger: writing reg 0x0D restarts the envelope
  if (r === 0x0d) {
   this._envPhase = 0;
   this._envClock = 0;
   this._envTrigger = true;
  }

  // Port write callbacks
  if (r === 0x0e && this.portAWrite) this.portAWrite(val & 0xff);
  if (r === 0x0f && this.portBWrite) this.portBWrite(val & 0xff);

  this._update();
 }

 readData() {
  if (this.addrLatch === 0x0e && this.portARead) return this.portARead() & 0xff;
  if (this.addrLatch === 0x0f && this.portBRead) return this.portBRead() & 0xff;
  return this.regs[this.addrLatch];
 }

 // Call once per frame from the emulation loop (NOT every writeData).
 // cycles = sound CPU cycles elapsed this frame, used to advance envelope & noise.
 tick(cycles) {
  if (!this.ctx) return;
  this._advanceEnvelope(cycles);
  this._advanceNoise(cycles);
  this._update();
 }

 _advanceEnvelope(cycles) {
  // Envelope period = (regs[0x0C] << 8 | regs[0x0B]) * 16 clocks per step
  const period = ((this.regs[0x0c] << 8) | this.regs[0x0b]) * 16 || 16;
  this._envClock += cycles;
  const steps = Math.floor(this._envClock / period);
  if (steps > 0) {
   this._envClock %= period;
   const shape = this.regs[0x0d] & 0x0f;
   const tbl = AY8910.ENVELOPE_SHAPES[shape];
   this._envPhase = Math.min(31, this._envPhase + steps);
  }
 }

 _advanceNoise(cycles) {
  // Noise period = regs[0x06] & 0x1F, each step = 16 clocks
  const nperiod = (this.regs[0x06] & 0x1f) * 16 || 16;
  this._noiseClock += cycles;
  let steps = Math.floor(this._noiseClock / nperiod);
  this._noiseClock %= nperiod;
  while (steps-- > 0) {
   // 17-bit Galois LFSR (taps at bits 0 and 3 per AY-8910 datasheet)
   const bit0 = this._noiseShift & 1;
   this._noiseShift =
    (this._noiseShift >> 1) | ((bit0 ^ ((this._noiseShift >> 3) & 1)) << 16);
   this._noiseBit = bit0;
  }
 }

 _update() {
  if (!this.ctx) return;
  const now = this.ctx.currentTime;

  for (let ch = 0; ch < 3; ch++) {
   const fine = this.regs[ch * 2];
   const coarse = this.regs[ch * 2 + 1] & 0x0f;
   const period = (coarse << 8) | fine;
   const volReg = this.regs[0x08 + ch];
   const envMode = (volReg & 0x10) !== 0; // bit 4: use envelope
   const toneOff = ((this.regs[0x07] >> ch) & 1) !== 0;
   const noiseOff = ((this.regs[0x07] >> (ch + 3)) & 1) !== 0;
   const channel = this.channels[ch];
   if (!channel) continue;

   // Amplitude: envelope or fixed level
   const envLevel =
    AY8910.ENVELOPE_SHAPES[this.regs[0x0d] & 0x0f][this._envPhase];
   const rawVol = envMode ? envLevel : volReg & 0x0f;

   // Gate: tone or noise must be enabled and have non-zero period
   const toneActive = !toneOff && period > 0;
   const noiseActive = !noiseOff && this._noiseBit;
   const active = toneActive || noiseActive;

   if (!active || rawVol === 0) {
    channel.gain.gain.setTargetAtTime(0, now, 0.004);
    continue;
   }

   if (toneActive && period > 0) {
    const freq = this.clock / (16 * period);
    channel.osc.frequency.setTargetAtTime(
     Math.max(20, Math.min(freq, 20000)),
     now,
     0.004
    );
   }

   const amplitude = AY8910.VOLUME_TABLE[rawVol] * 0.33;
   channel.gain.gain.setTargetAtTime(amplitude, now, 0.004);
  }
 }
}

// ── Starfield (galaxian_state::draw_stars / scramble variant) ─
class Starfield {
 constructor(width, height) {
  this.STAR_RNG_PERIOD = (1 << 17) - 1;
  this.W = width;
  this.H = height;
  this._rngOrigin = 0;
  this._originFrame = 0;
  this._flipX = false;
  this._stars = new Uint8Array(this.STAR_RNG_PERIOD);
  this._generate();
 }

 // galaxian_state::stars_init_w — pre-compute LFSR sequence
 _generate() {
  let shiftreg = 0;
  for (let i = 0; i < this.STAR_RNG_PERIOD; i++) {
   const enabled = (shiftreg & 0x1fe01) === 0x1fe00;
   const color = (~shiftreg & 0x1f8) >> 3;
   this._stars[i] = (color & 0x3f) | (enabled ? 0x80 : 0);
   const newbit = ((shiftreg >> 12) ^ ~shiftreg) & 1;
   shiftreg = ((shiftreg >> 1) | (newbit << 16)) & this.STAR_RNG_PERIOD;
  }
 }

 // galaxian_state::stars_update_origin — per-frame scroll
 updateOrigin(frameNumber, flipX = false) {
  this._flipX = flipX;
  if (frameNumber === this._originFrame) return;
  const perFrameDelta = flipX ? 1 : -1;
  let totalDelta = perFrameDelta * (frameNumber - this._originFrame);
  while (totalDelta < 0) totalDelta += this.STAR_RNG_PERIOD;
  this._rngOrigin = (this._rngOrigin + totalDelta) % this.STAR_RNG_PERIOD;
  this._originFrame = frameNumber;
 }

 // galaxian_state::stars_draw_row — 2 RNG clocks per logical pixel
 _drawRow(pixels, y, dispW, starmask, paletteRGB) {
  let staroffs = (this._rngOrigin + y * 512) % this.STAR_RNG_PERIOD;
  const rowBase = y * dispW * 3;

  for (let x = 0; x < dispW; x++) {
   const enableStar = (y ^ (x >> 3)) & 1;

   let star = this._stars[staroffs];
   if (++staroffs >= this.STAR_RNG_PERIOD) staroffs = 0;
   if (enableStar && star & 0x80 && star & starmask)
    pixels[rowBase + x * 3] = paletteRGB[star & 0x3f];

   star = this._stars[staroffs];
   if (++staroffs >= this.STAR_RNG_PERIOD) staroffs = 0;
   if (enableStar && star & 0x80 && star & starmask) {
    const color = paletteRGB[star & 0x3f];
    pixels[rowBase + x * 3 + 1] = color;
    pixels[rowBase + x * 3 + 2] = color;
   }
  }
 }

 render(pixels, dispW, dispH, blinkState, paletteRGB) {
  const colormaskTable = [0x20, 0x08, 0xff, 0xff]; // MAME colormask_table
  const starmask = colormaskTable[blinkState & 3];
  for (let y = 0; y < dispH; y++) {
   if ((blinkState & 3) === 2 && (y & 2) === 0) continue;
   this._drawRow(pixels, y, dispW, starmask, paletteRGB);
  }
 }
}

// ── Tilemap ───────────────────────────────────────────────
class Tilemap {
 constructor({
  cols,
  rows,
  tileW,
  tileH,
  getTileInfo,
  scan,
  visibleRowStart = 0,
  visibleRowEnd = 32
 }) {
  this.cols = cols;
  this.rows = rows;
  this.tileW = tileW;
  this.tileH = tileH;
  this.getTileInfo = getTileInfo;
  this.scan = scan;
  this.visibleRowStart = visibleRowStart;
  this.visibleRowEnd = visibleRowEnd;
  this.dirty = new Uint8Array(cols * rows).fill(1);
  this.cache = new Array(cols * rows);
 }
 markTileDirty(tileIndex) {
  if (tileIndex >= 0 && tileIndex < this.dirty.length)
   this.dirty[tileIndex] = 1;
 }
 markAllDirty() {
  this.dirty.fill(1);
 }

 draw(pixels, screenW, screenH, paletteRGB, opts = {}) {
  const scrollX = (opts.scrollX ?? 0) & 0xff;

  for (let row = this.visibleRowStart; row < this.visibleRowEnd; row++) {
   const baseScreenY = (row - this.visibleRowStart) * this.tileH;
   const isHUD = row < 5 || row >= 30;
   const colScroll = isHUD ? 0 : scrollX;

   for (let col = 0; col < this.cols; col++) {
    const info = this._getCachedTileInfo(col, row);
    if (!info?.tile) continue;

    const baseScreenX = (col * this.tileW - colScroll + screenW) % screenW;
    this._drawTile(
     pixels,
     screenW,
     screenH,
     paletteRGB,
     info,
     baseScreenX,
     baseScreenY
    );
   }
  }
 }
 _getCachedTileInfo(col, row) {
  const i = this.scan(col, row);
  if (this.dirty[i]) {
   this.cache[i] = this.getTileInfo(i);
   this.dirty[i] = 0;
  }
  return this.cache[i];
 }
 _drawTile(
  pixels,
  screenW,
  screenH,
  paletteRGB,
  info,
  baseScreenX,
  baseScreenY
 ) {
  const { tile, colorBase } = info;
  const clipLeft = 14; // hide 2 leftmost columns
  const clipRight = screenW - 8; // hide 2 rightmost columns

  for (let py = 0; py < this.tileH; py++) {
   const destY = baseScreenY + py;
   if (destY < 0 || destY >= screenH) continue;

   const screenRowOffset = destY * screenW;
   const tileRowOffset = py * this.tileW;

   for (let px = 0; px < this.tileW; px++) {
    const pen = tile[tileRowOffset + px];
    if (!pen) continue;

    const destX = screenW - 2 - ((baseScreenX + px) % screenW);
    if (destX < clipLeft || destX >= clipRight) continue;

    pixels[screenRowOffset + destX] = paletteRGB[(colorBase | pen) & 0x1f];
   }
  }
 }
}

// ── Inputs ────────────────────────────────────────────────
class Touchpads {
  constructor(inputs = {}) {
    this.inputs      = inputs;
    this.DEADZONE    = 20;
    this.DPAD_RADIUS = 100;
    this.RING_RADIUS = 18;       // size of the touch indicator ring
    this.dpadTouchId = null;
    this.fireTouchId = null;
    this.bombTouchId = null;
    this.dpadCtx     = null;
    this.initDOM();
    this.bindEvents();
  }

  initDOM() {
    this.dpadEl = document.getElementById('dpad-ring');
    this.fireEl = document.getElementById('btn-fire');
    this.bombEl = document.getElementById('btn-bomb');

    const canvas = document.getElementById('dpad-canvas');
    if (canvas) {
      this.dpadCtx = canvas.getContext('2d');
    }
  }

  bindEvents() {
    if (this.dpadEl) {
      const opts = { passive: false };
      this.dpadEl.addEventListener('touchstart',  e => this._dpadStart(e),  opts);
      this.dpadEl.addEventListener('touchmove',   e => this._dpadMove(e),   opts);
      this.dpadEl.addEventListener('touchend',    e => this._dpadEnd(e),    opts);
      this.dpadEl.addEventListener('touchcancel', e => this._dpadEnd(e),    opts);
    }
    this._bindButton(this.fireEl, 'fire', 'fireTouchId');
    this._bindButton(this.bombEl, 'bomb', 'bombTouchId');
  }

  // ── BUTTON BINDER ────────────────────────────────────────────────────────

  _bindButton(el, inputName, touchIdKey) {
    if (!el) return;
    const opts = { passive: false };
    el.addEventListener('touchstart', e => {
      e.preventDefault();
      if (this[touchIdKey] !== null) return;
      this[touchIdKey] = e.changedTouches[0].identifier;
      this.setInput(inputName, true);
    }, opts);
    el.addEventListener('touchmove',   e => e.preventDefault(), opts);
    const release = e => {
      e.preventDefault();
      for (const t of e.changedTouches) {
        if (t.identifier === this[touchIdKey]) {
          this[touchIdKey] = null;
          this.setInput(inputName, false);
          break;
        }
      }
    };
    el.addEventListener('touchend',    release, opts);
    el.addEventListener('touchcancel', release, opts);
  }

  // ── DPAD HANDLERS ────────────────────────────────────────────────────────

  _dpadStart(e) {
    e.preventDefault();
    if (this.dpadTouchId !== null) return;
    const t = e.changedTouches[0];
    this.dpadTouchId = t.identifier;
    this.updateDpad(t);
  }

  _dpadMove(e) {
    e.preventDefault();
    for (const t of e.changedTouches) {
      if (t.identifier === this.dpadTouchId) { this.updateDpad(t); break; }
    }
  }

  _dpadEnd(e) {
    e.preventDefault();
    for (const t of e.changedTouches) {
      if (t.identifier === this.dpadTouchId) {
        this.dpadTouchId = null;
        this.clearDpad();
        break;
      }
    }
  }

  // ── INPUTS ───────────────────────────────────────────────────────────────

  setInput(name, state) {
    if (this.inputs.setInput) this.inputs.setInput(name, state);
  }

  pulseInput(name) {
    if (this.inputs.pulseInput) this.inputs.pulseInput(name);
  }

  clearDpad() {
    ['left', 'right', 'up', 'down'].forEach(n => this.setInput(n, false));
    this.clearCanvas();
  }

  // ── DPAD LOGIC ───────────────────────────────────────────────────────────

  updateDpad(touch) {
    const rect = this.dpadEl.getBoundingClientRect();
    const dx   = touch.clientX - (rect.left + rect.width  / 2);
    const dy   = touch.clientY - (rect.top  + rect.height / 2);
    const dist = Math.hypot(dx, dy);

    // Clamp to radius for the visual, use raw for input
    const clamp = Math.min(dist, this.DPAD_RADIUS);
    const angle = Math.atan2(dy, dx);
    const cx    = Math.cos(angle) * clamp;
    const cy    = Math.sin(angle) * clamp;
    this.drawTouchRing(cx, cy, dist);

    if (dist < this.DEADZONE) { this.clearDpadInputs(); return; }

    const PI4 = Math.PI / 4;
    this.setInput('right', angle > -PI4     && angle <  PI4);
    this.setInput('down',  angle >  PI4     && angle <  PI4 * 3);
    this.setInput('left',  angle >  PI4 * 3 || angle < -PI4 * 3);
    this.setInput('up',    angle > -PI4 * 3 && angle < -PI4);
  }

  clearDpadInputs() {
    ['left', 'right', 'up', 'down'].forEach(n => this.setInput(n, false));
  }

  // ── DRAWING ──────────────────────────────────────────────────────────────

  clearCanvas() {
    if (!this.dpadCtx) return;
    this.dpadCtx.clearRect(0, 0, 200, 200);
  }

  drawTouchRing(tx, ty, dist) {
    if (!this.dpadCtx) return;
    const ctx   = this.dpadCtx;
    const alpha = dist < this.DEADZONE
      ? 0.25                                        // faint ring in dead zone
      : Math.min(1, dist / this.DPAD_RADIUS);

    ctx.clearRect(0, 0, 200, 200);
    ctx.beginPath();
    ctx.arc(100 + tx, 100 + ty, this.RING_RADIUS, 0, Math.PI * 2);
    ctx.strokeStyle = `rgba(255, 255, 255, ${alpha})`;
    ctx.lineWidth   = 2;
    ctx.stroke();
  }
}

// ── ScrambleEmu ───────────────────────────────────────────
class ScrambleEmu {
 constructor(canvasId) {
  // Logical input state (matches MAME input definitions conceptually)
  this.inputs = {
   up: false,
   down: false,
   left: false,
   right: false,
   fire: false,
   bomb: false,
   coin1: false,
   coin2: false,
   start1: false,
   start2: false,
   service: false // add this for IN0 service/test
  };
  this.initTimingConstants();
  this.initRomConfig();
  this.initCanvas(canvasId);
  this.initMemory();
  this.initVideoBuffers();
  this.initMachineState();
  this.initInputs();
  this.initRuntimeState();
 } cc
 initTimingConstants() {
  this.CPUCLOCK = 3_072_000;
  this.SOUNDCLOCK = 14_318_000 / 8;
  this.FRAMERATE = 16000 / 132 / 2;
  this.WIDTH = this.HEIGHT = 256;

  this.cyclesPerFrame = Math.floor(this.CPUCLOCK / this.FRAMERATE);
  this.QUANTUM = Math.floor(this.cyclesPerFrame / 4);
  this.soundCyclesPerFrame = Math.floor(this.SOUNDCLOCK / this.FRAMERATE);
  this.soundQuantum = Math.floor(this.soundCyclesPerFrame / 4);
 }
 initRomConfig() {
  this.ROMS = {
   main: ["2d", "2e", "2f", "2h", "2j", "2l", "2m", "2p"],
   sound: ["ot1.5c", "ot2.5d", "ot3.5e"],
   gfx: ["5f", "5h"],
   prom: "c01s.6e"
  };
  this.romBaseUrl = "https://subnetpie.github.io/scramble/";
 }
 initCanvas(canvasId) {
  this.canvas =
   document.getElementById(canvasId) ??
   (() => {
    throw new Error(`Canvas '${canvasId}' missing`);
   })();
  this.ctx = this.canvas.getContext("2d");
  this.canvas.width = this.WIDTH;
  this.canvas.height = this.HEIGHT;
  this.canvas.style.imageRendering = "pixelated";
 }
 initMemory() {
  this.mem = new Uint8Array(0x10000);
  this.soundRom = new Uint8Array(0x3000);
  this.soundRam = new Uint8Array(0x1000);
 }
 initMachineState() {
  // Video / board latches
  this.nmiEnable   = 0;
  this.starsEnable = 0;
  this.flipScreenX = 0;
  this.flipScreenY = 0;
  this.bgScrollX   = 0;

  // Sound / communication
  this.soundLatch      = 0;
  this.soundIrqPending = false;

  // Coins / bookkeeping
  this.freePlay         = false;
  this.prevCoinCounter1 = false;

  // Seed credit / input-history RAM so the ROM starts in a sane state
  this.mem[0x4002] = 0;    // 1 initial credit

  this.mem[0x4010] = 0x00;
  this.mem[0x4011] = 0x00;
  this.mem[0x4012] = 0x00;
  this.mem[0x4013] = 0x00;
  this.mem[0x4014] = 0x00;
  this.mem[0x4015] = 0x00;
  this.mem[0x4016] = 0x00;
  this.mem[0x4017] = 0x00;
  this.mem[0x4018] = 0x00;
 }
 initInputs() {
  this.touchBindings = {
    up:     { field: 'up' },
    down:   { field: 'down' },
    left:   { field: 'left' },
    right:  { field: 'right' },
    fire:   { field: 'fire' },
    bomb:   { field: 'bomb' },
    coin1:  { field: 'coin1',  pulse: true },
    coin2:  { field: 'coin2',  pulse: true },
    start1: { field: 'start1', pulse: true },
    start2: { field: 'start2', pulse: true }
  };
  this.touchTimers = new Map();
  this.bindTouchControls();
  this.bindKeyboardAndMouse();

  // Touchpads handles dpad-ring and action-pad internally
  this.touchpads = new Touchpads({
    setInput:   (name, state) => this.setInput(name, state),
    pulseInput: (name)        => this.pulseInput(name)
  });
}
 bindTouchControls() {
  const bindTouchElement = (el, pressFn, releaseFn) => {
    const opts = { passive: false };
    el.addEventListener('touchstart',  e => { e.preventDefault(); pressFn(e); },   opts);
    el.addEventListener('touchend',    e => { e.preventDefault(); releaseFn(e); }, opts);
    el.addEventListener('touchcancel', e => { e.preventDefault(); releaseFn(e); }, opts);
    el.addEventListener('touchmove',   e => { e.preventDefault(); pressFn(e); },   opts);
  };

  // ── Discrete buttons only (coin, start, etc.) ─────────────────────────
  document.querySelectorAll('[data-btn]').forEach(el => {
    const name = el.dataset.btn;
    const b = this.touchBindings[name];
    if (!b) return;
    bindTouchElement(el,
      () => b.pulse ? this.pulseInput(name) : this.setInput(name, true),
      () => !b.pulse && this.setInput(name, false)
    );
  });

  // iOS Safari: unlock AudioContext on first touch gesture
  document.body.addEventListener('touchstart', () => this.resumeAudio(),
  { once: true, passive: true });
}
 resetInputPorts() {
  // reset logical inputs to neutral + DIP defaults are in readINx
  Object.keys(this.inputs).forEach((k) => {
   this.inputs[k] = false;
  });
 }
 setInput(name, active) {
  const b = this.touchBindings[name];
  if (!b) return;
  this.inputs[b.field] = !!active;
 }
 pulseInput(name, duration = 200) {
  this.setInput(name, true);
  clearTimeout(this.touchTimers.get(name));
  this.touchTimers.set(
   name,
   setTimeout(() => {
    this.setInput(name, false);
    this.touchTimers.delete(name);
   }, duration)
  );
 }
 bindKeyboardAndMouse() {
  const keyDown = (e) => {
    this.resumeAudio();        
    switch (e.code) {
      case "ArrowLeft":  this.setInput("left",  true); break;
      case "ArrowRight": this.setInput("right", true); break;
      case "ArrowUp":    this.setInput("up",    true); break;
      case "ArrowDown":  this.setInput("down",  true); break;
      case "Space":      this.setInput("fire",  true); break;
      case "ShiftLeft": this.setInput("bomb",  true); break;
      case "Digit1":     this.pulseInput("start1");    break;
      case "Digit2":     this.pulseInput("start2");    break;
      case "Digit5":     this.pulseInput("coin1");     break;
    }
  };

  const keyUp = (e) => {
    switch (e.code) {
      case "ArrowLeft":  this.setInput("left",  false); break;
      case "ArrowRight": this.setInput("right", false); break;
      case "ArrowUp":    this.setInput("up",    false); break;
      case "ArrowDown":  this.setInput("down",  false); break;
      case "Space":      this.setInput("fire",  false); break;
      case "ShiftLeft":  this.setInput("bomb",  false); break;
      case "Digit1":     this.pulseInput("start1");    break;
      case "Digit2":     this.pulseInput("start2");    break;
      case "Digit5":     this.pulseInput("coin1");     break;
    }
  };

  window.addEventListener("keydown", keyDown);
  window.addEventListener("keyup",   keyUp);
  window.addEventListener('click', () => this.resumeAudio(), { once: true });

  // Mouse: left button acts like a virtual stick+fire, right button for coin/start
  const mouseDown = (e) => {
    e.preventDefault();
    const rect = this.canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (e.button === 0) {
      // Left button: aim ship horizontally + fire
      const centerX = rect.width / 2;
      this.setInput("left",  x < centerX);
      this.setInput("right", x > centerX);
      this.setInput("fire",  true);
    } else if (e.button === 2) {
      // Right button: coin1 pulse
      this.pulseInput("coin1");
    }
  };

  const mouseUp = (e) => {
    e.preventDefault();
    if (e.button === 0) {
      this.setInput("left",  false);
      this.setInput("right", false);
      this.setInput("fire",  false);
    }
    // no release needed for coin pulse
  };

  this.canvas.addEventListener("mousedown", mouseDown);
  this.canvas.addEventListener("mouseup",   mouseUp);
  this.canvas.addEventListener("contextmenu", (e) => e.preventDefault());
 }
 initRuntimeState() {
  this.running = false;
  this.frameCount = 0;
  this.lastFrameTime = 0;
  this.starsBlinkState = 0;
  this.starsBlinkCounter = 0;

  this.tiles = null;
  this.sprites = null;
  this.paletteRGB = null;
  this.starPaletteRGB = null;
  this.bgTilemap = null;

  this.ready = false;

  this.traceEnabled = true;
  this.traceLog = [];
  this.maxTrace = 4000;
  this.lastOpPC = 0;

  this.touchTimers ??= new Map();
  this.touchBindings ??= {};
 }
 initVideoBuffers() {
  this.imageData = this.ctx.createImageData(this.WIDTH, this.HEIGHT);
  this.starfield = new Starfield(this.WIDTH, this.HEIGHT);
 }
 initIO() {
  this.ppiCReady = false;

  this.ppi0 = new PPI8255(
    this.readIN0.bind(this), // PA = IN0
    this.readIN1.bind(this), // PB = IN1
    () => {
      const base = this.readIN2();
      // PC7 is a "ready" bit that the game polls in early init
      return this.ppiCReady ? base | 0x80 : base & ~0x80;
    },
    null, null, null
  );

  // Scramble PPI1 uses stride-2 addressing:
  //   0x8200 (off=0) → (0>>1)&3 = 0 → PA: sound command latch
  //   0x8202 (off=2) → (2>>1)&3 = 1 → PC: bit-0 low = assert sound IRQ
  // Both map correctly with (off >> 1) & 3.
  this.ppi1 = {
    em: this,
    mode: 0x90,
    read(off) {
      return 0xff;
    },
    write(off, v) {
      v &= 0xff;
      const p = (off >> 1) & 3;   // stride-2: 0x8200→0, 0x8202→1
      switch (p) {
        case 0:  // 0x8200 PA → sound command latch
          this.em.soundLatch = v;
          break;
        case 1:  // 0x8202 PC → bit 0 low asserts INT on sound CPU
          if ((v & 1) === 0) this.em.soundIrqPending = true;
          break;
        // case 2 / 3 unreachable with off in [0..3]
      }
    }
  };
 }
 resumeAudio() {
  if (this._audioCtx?.state === 'suspended') this._audioCtx.resume();
 }
 updateSelfTestGate() {
  if (!this.ppiCReady && this.cpu && this.cpu.PC === 0x016f) {
   this.ppiCReady = true;
  }
 }

 // ── PPI0 ports, MAME-style: derive from this.inputs + DIPs ──
 readIN0() {
  const inp = this.inputs;
  let v = 0xff;

  // MAME Scramble IN0 bits (all active low):
  // 0x01: P1 up (unused here)
  // 0x02: P1 button2 (bomb)
  // 0x04: service1
  // 0x08: P1 button1 (fire)
  // 0x10: P1 right
  // 0x20: P1 left
  // 0x40: coin2
  // 0x80: coin1

  if (inp.coin1)   v &= ~0x80;
  if (inp.coin2)   v &= ~0x40;
  if (inp.right)   v &= ~0x10;
  if (inp.left)    v &= ~0x20;
  if (inp.fire)    v &= ~0x08;
  if (inp.bomb)    v &= ~0x02;
  if (inp.service) v &= ~0x04;

  return v;
}
 readIN1() {
  const inp = this.inputs || {};
  let v = 0xff;

  // Lives DIP: 3 lives (00)
  v &= ~0x03;
  // Coinage DIP: A 1C/1C B 1C/1C (00)
  v &= ~0x0c;

  if (inp.start2) v &= ~0x40; // bit 6
  if (inp.start1) v &= ~0x80; // bit 7

  return v;
}
 readIN2() {
  const inp = this.inputs || {};
  let v = 0xff;

  if (inp.up) v &= ~0x10; // bit 4
  if (inp.down) v &= ~0x40; // bit 6

  // bits 0–3,5,7: keep high (DIPs/unused)
  return v;
 }

 async loadROM(name) {
  try {
   const res = await fetch(`${this.romBaseUrl}${name}`);
   if (!res.ok) return null;
   return new Uint8Array(await res.arrayBuffer());
  } catch {
   return null;
  }
 }
 async init() {
  // ── Load program + data ROMs ─────────────────────────────
  const [mainRoms, soundRoms, gfx0, gfx1, prom] = await Promise.all([
    Promise.all(this.ROMS.main.map((n) => this.loadROM(n))),
    Promise.all(this.ROMS.sound.map((n) => this.loadROM(n))),
    this.loadROM(this.ROMS.gfx[0]),
    this.loadROM(this.ROMS.gfx[1]),
    this.loadROM(this.ROMS.prom)
  ]);

  // Main CPU ROMs at 0x0000–0x3FFF
  mainRoms.forEach((rom, i) => {
    if (!rom) return;
    this.mem.set(rom.subarray(0, 0x800), i * 0x800);
  });

  // PATCH: bypass Stern decrypted ROM self-test RET NZ at 0x01a9
  this.mem[0x01a9] = 0x00;

  // Sound CPU ROMs at 0x0000–0x2FFF
  soundRoms.forEach((rom, i) => {
    if (!rom) return;
    this.soundRom.set(rom.subarray(0, 0x800), i * 0x800);
  });

  // ── Build GFX-derived assets ──────────────────────────────
  const charROM = new Uint8Array(0x1000);
  if (gfx0) charROM.set(gfx0.subarray(0, 0x800), 0x0000);
  if (gfx1) charROM.set(gfx1.subarray(0, 0x800), 0x0800);

  this.paletteRGB    = this.buildPalette(prom);
  this.starPaletteRGB = this.buildStarPalette();
  this.tiles         = this.buildTiles(charROM);
  this.sprites       = this.buildSprites(charROM);
  this.createTilemap();

  // ── Audio ─────────────────────────────────────────────────
// ── Audio ───────────────────────────────────────────────
try {
  const Ctx = window.AudioContext || window.webkitAudioContext;
  this._audioCtx = new Ctx();
  // ay1 Port A is the sound-command bus: sound CPU reads soundLatch via reg 0x0E
  this.ay1 = new AY8910(this._audioCtx, this.SOUNDCLOCK, () => this.soundLatch);
  this.ay2 = new AY8910(this._audioCtx, this.SOUNDCLOCK);
} catch {
  this._audioCtx = null;
  this.ay1 = new AY8910(null, this.SOUNDCLOCK, () => this.soundLatch);
  this.ay2 = new AY8910(null, this.SOUNDCLOCK);
}


  // ── IO (PPIs) before CPU reset ────────────────────────────
  this.initIO();

  // ── Main CPU ──────────────────────────────────────────────
  this.cpu = new Z80(
    (addr)       => this.read(addr),
    (addr, data) => this.write(addr, data),
    ()           => 0xff,
    ()           => {}
  );
  this.cpu.reset();
  this.cpu.SP   = 0xffff;
  this.cpu.IFF1 = this.cpu.IFF2 = false;
  this.cpu.IM   = 1;

  // Instrument main CPU
  this.opCount = 0;
  const oldStep = this.cpu.step.bind(this.cpu);
  this.cpu.step = () => { this.opCount++; return oldStep(); };

  // ── Sound CPU ─────────────────────────────────────────────
  this.soundCpu = new Z80(
    (addr)       => this.soundRead(addr),
    (addr, data) => this.soundWrite(addr, data),
    (port)       => this.soundPortRead(port),
    (port, data) => this.soundPortWrite(port, data)
  );
  this.soundCpu.reset();
  this.soundCpu.SP   = 0xffff;
  this.soundCpu.IFF1 = this.soundCpu.IFF2 = false;
  this.soundCpu.IM   = 1;

  this.resetInputPorts();
  this.initMachineState();
  this.ready = true;
 }
 async start() {
  if (!this.ready) await this.init();
  this.running = true;
  requestAnimationFrame((ts) => this.stepFrame(ts));
 }
 stop() {
  this.running = false;
 }

 stepFrame(timestamp) {
  if (!this.running || !this.cpu || !this.soundCpu) return;

  const frameInterval = 1000 / this.FRAMERATE;
  if (timestamp - this.lastFrameTime < frameInterval - 1) {
   requestAnimationFrame((ts) => this.stepFrame(ts));
   return;
  }

  this.lastFrameTime = timestamp;

  let mainLeft = this.cyclesPerFrame;
  let soundLeft = this.soundCyclesPerFrame;

  // init histogram once
  if (!this.pcHistogram) this.pcHistogram = new Uint32Array(0x4000);

  for (let slice = 0; slice < 4; slice++) {
   const mainBudget = slice < 3 ? this.QUANTUM : mainLeft;
   const soundBudget = slice < 3 ? this.soundQuantum : soundLeft;

   // main CPU
   let mainElapsed = 0;
   while (mainElapsed < mainBudget) {
    this.updateSelfTestGate(); // new line

    this.lastOpPC = this.cpu.PC;
    if (this.cpu.PC < 0x4000) this.pcHistogram[this.cpu.PC]++;
    mainElapsed += this.cpu.step();
   }
   mainLeft -= mainElapsed;

   // sound CPU
   let soundElapsed = 0;
   while (soundElapsed < soundBudget) {
    soundElapsed += this.soundCpu.step();
   }
   soundLeft -= soundElapsed;

   if (slice === 3) {
    if (this.nmiEnable) this.cpu.requestNmi();
    if (this.soundIrqPending) {
     this.soundIrqPending = false;
     this.soundCpu.requestIrq(0xff);
    }
    if (this.starsEnable) {
     if (++this.starsBlinkCounter >= 20) {
      this.starsBlinkCounter = 0;
      this.starsBlinkState = (this.starsBlinkState + 1) & 3;
     }
    }
   }
  }
  
  this.ay1?.tick(this.soundCyclesPerFrame);
  this.ay2?.tick(this.soundCyclesPerFrame);

  this.frameCount++;
  this.render(this.frameCount);
  
  requestAnimationFrame((ts) => this.stepFrame(ts));
 }

 // ── Main CPU memory map ─────────────────────────────
 read(addr) {
  addr &= 0xffff;

  // 0000–3FFF: program ROM
  if (addr <= 0x3fff) return this.mem[addr];

  // 4000–47FF: work RAM
  if (addr >= 0x4000 && addr <= 0x47ff) return this.mem[addr];

  // 4800–4BFF: video RAM
  if (addr >= 0x4800 && addr <= 0x4bff) return this.mem[addr];

  // 4C00–4FFF: VRAM mirror of 4800–4BFF
  if (addr >= 0x4c00 && addr <= 0x4fff)
   return this.mem[0x4800 + (addr & 0x03ff)];

  // 5000–50FF: sprite / attribute RAM
  if (addr >= 0x5000 && addr <= 0x50ff) return this.mem[addr];

  // Scramble-style inputs: mirrors
  // 6000–67FF: IN0 mirrors
  if (addr >= 0x6000 && addr <= 0x67ff) {
    const v = this.readIN0();
    return v;
  }
  if (addr >= 0x6800 && addr <= 0x6fff) return this.readIN1(); // IN1
  // 7000–77FF: IN2 mirrors (optional)
  if (addr >= 0x7000 && addr <= 0x77ff) {
    const v = this.readIN2();
    return v;
  }

  // 8100–8103: PPI0 (already mapped)
  if (addr >= 0x8100 && addr <= 0x8103) {
    const v = this.ppi0.read(addr & 3);
    return v;
  }
  // 7800–7FFF: watchdog / unused
  if (addr >= 0x7800 && addr <= 0x7fff) return 0xff;

   // 8200–8203: PPI1 sound
  if (addr >= 0x8200 && addr <= 0x8203) {
   const v = this.ppi1.read(addr & 3);
   return v;
  }

  // everything else: open bus
  return 0xff;
 }
 write(addr, data) {
  addr &= 0xffff;
  data &= 0xff;
  const bg = this.bgTilemap;

  // 0000–3FFF: ROM, ignore writes
  if (addr <= 0x3fff) return;

  // 4000–47FF: work RAM
  if (addr >= 0x4000 && addr <= 0x47ff) {
   const old = this.mem[addr];
   this.mem[addr] = data;
   return;
  }

  // 4800–4BFF: video RAM
  if (addr >= 0x4800 && addr <= 0x4bff) {
   const old = this.mem[addr];
   this.mem[addr] = data;
   bg?.markTileDirty(addr - 0x4800);
   return;
  }

  // 4C00–4FFF: VRAM mirror
  if (addr >= 0x4c00 && addr <= 0x4fff) {
   const real = 0x4800 + (addr & 0x03ff);
   const old = this.mem[real];
   this.mem[real] = data;
   if (old !== data) {
    this.trace("vram-mirror-write", { addr, real, old, data });
    bg?.markTileDirty(addr & 0x03ff);
   }
   return;
  }

  // 5000–503F: attribute RAM / scroll
  if (addr >= 0x5000 && addr <= 0x503f) {
   const old = this.mem[addr];
   this.mem[addr] = data;
   const hwCol = (addr - 0x5000) >> 1;
   if ((addr & 1) === 0 && hwCol < 28) this.bgScrollX = data & 0xff;
   this.markAttrColumnDirty(hwCol);
   return;
  }

  // 5040–50FF: sprite table
  if (addr >= 0x5040 && addr <= 0x50ff) {
   const old = this.mem[addr];
   this.mem[addr] = data;
   return;
  }
  // 6800–6807: NMI/stars/flip/coin counters (Scramble-style)

  if (addr >= 0x6800 && addr <= 0x6807) {
   
   const bit = data & 1;
   switch (addr) {
    case 0x6800:
     return; // often unused/service
    case 0x6801:
     this.nmiEnable = bit;
     return;
    case 0x6802: {
      // Rising edge of the ROM's coin counter pulse = valid coin
      const rising = bit && !this.prevCoinCounter1;
      if (rising) {
        this.mem[0x4002] = (this.mem[0x4002] + 1) & 0xff;
      }
      this.prevCoinCounter1 = !!bit;
      return;
    }
    case 0x6803:
     return;
    case 0x6804:
     this.starsEnable = bit;
     return;
    case 0x6805:
     return;
    case 0x6806:
     if (this.flipScreenX !== bit) this.bgTilemap?.markAllDirty();
     this.flipScreenX = bit;
     return;
    case 0x6807:
     if (this.flipScreenY !== bit) this.bgTilemap?.markAllDirty();
     this.flipScreenY = bit;
     return;
    default:
     return;
   }
  }

  // 7800–7FFF: watchdog/pitch – ignore writes for now
  if (addr >= 0x7800 && addr <= 0x7fff) {
   return;
  }

  // 8200–8203: PPI1 write
  if (addr >= 0x8200 && addr <= 0x8203) {
   this.ppi1.write(addr & 3, data);
   return;
  }
 }
 
 // Video
 getBackdropColor() {
  return this.paletteRGB?.[this.bgColorIndex] ?? 0xff000000;
 }
 buildPalette(prom) {
  const out = new Uint32Array(32);
  const bit = (v, n) => (v >> n) & 1;
  const sum3 = (v, s) =>
   bit(v, s) * 0x21 + bit(v, s + 1) * 0x47 + bit(v, s + 2) * 0x97;
  for (let i = 0; i < 32; i++) {
   const v = prom?.[i] ?? 0;
   const r = sum3(v, 0);
   const g = sum3(v, 3);
   const b = bit(v, 6) * 0x51 + bit(v, 7) * 0xae;
   out[i] = 0xff000000 | (b << 16) | (g << 8) | r;
  }
  return out;
 }
 buildStarPalette() {
  const out = new Uint32Array(64);
  const RGBMAX = 224;
  const minval = Math.round((RGBMAX * 130) / 150);
  const midsrc = Math.round((RGBMAX * 130) / 100);
  const maxval = Math.round((RGBMAX * 130) / 60);
  const midval = Math.round(
   minval + ((255 - minval) * (midsrc - minval)) / (maxval - minval)
  );
  const levels = [0, minval, midval, 255];
  const level2 = (value, loBit, hiBit) =>
   levels[((value >> hiBit) & 1) * 2 + ((value >> loBit) & 1)];
  for (let i = 0; i < 64; i++) {
   const r = level2(i, 5, 4);
   const g = level2(i, 3, 2);
   const b = level2(i, 1, 0);
   out[i] = 0xff000000 | (b << 16) | (g << 8) | r;
  }
  return out;
 }
 buildTiles(charROM) {
  return Array.from({ length: 256 }, (_, code) => {
   const tile = new Uint8Array(64);
   for (let y = 0; y < 8; y++) {
    const p0 = charROM[code * 8 + y] ?? 0;
    const p1 = charROM[0x800 + code * 8 + y] ?? 0;
    for (let x = 0; x < 8; x++) {
     const col = 7 - x;
     const pen = (((p1 >> col) & 1) << 1) | ((p0 >> col) & 1);
     tile[x * 8 + y] = pen;
    }
   }
   return tile;
  });
 }
 createTilemap() {
  this.bgTilemap = new Tilemap({
   cols: 32,
   rows: 32,
   tileW: 8,
   tileH: 8,
   visibleRowStart: 0,
   visibleRowEnd: 32,
   scan: (col, row) => (col << 5) | row,
   getTileInfo: (tileIndex) => {
    const col = tileIndex >> 5;
    const row = tileIndex & 0x1f;
    const attrCol = row;
    const code = this.mem[0x4800 + tileIndex];
    const attr = this.mem[0x5001 + ((attrCol & 0x1f) << 1)];
    const colorBase = (attr & 0x07) << 2;
    return { tile: this.tiles[code], colorBase };
   }
  });
 }
 renderTiles(pixels, width, height) {
  this.bgTilemap.draw(pixels, width, height, this.paletteRGB, {
   scrollX: this.bgScrollX
  });
 }
 buildSprites(charROM) {
  return Array.from({ length: 64 }, (_, code) => {
   const sprite = new Uint8Array(256);
   const base = code * 32;

   for (let y = 0; y < 16; y++) {
    const qRowOffset = (y >> 3) << 4;
    const rowInQuad = y & 7;

    for (let x = 0; x < 16; x++) {
     const qColOffset = (x >> 3) << 3;
     const bit = 7 - (x & 7);

     const idx = base + qRowOffset + qColOffset + rowInQuad;
     const p0 = charROM[idx] ?? 0;
     const p1 = charROM[0x800 + idx] ?? 0;
     const pen = (((p1 >> bit) & 1) << 1) | ((p0 >> bit) & 1);

     const dx = 15 - y;
     const dy = x;
     sprite[dy * 16 + dx] = pen;
    }
   }
   return sprite;
  });
 }
 renderSprites(pixels) {
  const clipLeft = 16;
  const clipRight = this.WIDTH - 16;
  
  // Sprite table: 0x5040–0x505F, 8 sprites x 4 bytes
  //  +0: X (inverted distance), +1: code/flip, +2: color, +3: Y raw
  for (let offs = 0x1c; offs >= 0; offs -= 4) {
   const rawX = this.mem[0x5040 + offs + 0];
   const codeRaw = this.mem[0x5040 + offs + 1];
   const colorByte = this.mem[0x5040 + offs + 2];
   const rawY = this.mem[0x5040 + offs + 3];

   if (!rawY && !rawX) continue;

   const code = codeRaw & 0x3f;
   let flipX = (codeRaw & 0x40) !== 0;
   let flipY = (codeRaw & 0x80) !== 0;

   const color = (colorByte & 0x07) << 2;

   const spr = this.sprites[code];
   if (!spr) continue;

   const sx0 = (rawX + 1) & 0xff; // landscape X
   const sy0 = (rawY + 256) & 0xff; // landscape Y

   for (let dy = 0; dy < 16; dy++) {
    const sy = (sy0 + dy) & 0xff;
    if (sy >= this.HEIGHT) continue;
    const screenRowOffset = sy * this.WIDTH;
    const py = flipX ? 15 - dy : dy;

    for (let dx = 0; dx < 16; dx++) {
     const sx = (sx0 + dx) & 0xff;
     if (sx < clipLeft || sx >= clipRight) continue;

     const px = flipY ? 15 - dx : dx;
     const pen = spr[py * 16 + px];
     if (!pen) continue;

     pixels[screenRowOffset + sx] = this.paletteRGB[(color | pen) & 0x1f];
    }
   }
  }
 }
 markAttrColumnDirty(col) {
  if (!this.bgTilemap) return;
  for (let row = 0; row < 32; row++) {
   this.bgTilemap.markTileDirty((col << 5) | row);
  }
 }
 drawBackdrop(pixels, width, height) {
  // optional: solid color or gradient
 }
 drawStars(pixels, width, height) {
  if (!this.starsEnable || !this.starfield) return;
  this.starfield.render(
   pixels,
   width,
   height,
   this.starsBlinkState & 3,
   this.starPaletteRGB
  );
 }
 drawBullets(pixels, width, height) {
  for (let i = 0; i < 8; i++) {
   const base = 0x5060 + i * 4;
   const rawY = this.mem[base + 1]; // portrait row  → landscape X
   const rawX = this.mem[base + 3]; // portrait col  → landscape Y

   const x = rawY & 0xff;
   const y = (256 - 8 - rawX) & 0xff;

   if (x <= 0 || x >= width - 1 || y <= 0 || y >= height - 1) continue;

   const offset = y * width + x;
   pixels[offset] = 0xffffffff;
   pixels[offset + 1] = 0xffffffff;
   pixels[offset + width] = 0xffffffff;
   pixels[offset + width + 1] = 0xffffffff;
  }
 }
 render() {
  if (!this.ready || !this.tiles || !this.paletteRGB || !this.bgTilemap) return;
  const pixels = new Uint32Array(this.imageData.data.buffer);
  const width = this.WIDTH;
  const height = this.HEIGHT;
  pixels.fill(0xff000000);
  
  this.drawBackdrop(pixels, width, height);
  this.drawStars(pixels, width, height);
  this.renderTiles(pixels, width, height);
  this.renderSprites(pixels);
  this.drawBullets(pixels, width, height);
  this.ctx.putImageData(this.imageData, 0, 0);
 }
 
 // Sound
 soundRead(addr) {
  addr &= 0xffff;
  if (addr <= 0x2fff) return this.soundRom[addr];
  if (addr >= 0x8000 && addr <= 0x8fff) return this.soundRam[addr & 0x03ff];
  return 0xff;
 }
 soundWrite(addr, data) {
  addr &= 0xffff;
  data &= 0xff;
  if (addr >= 0x8000 && addr <= 0x8fff) {
   this.soundRam[addr & 0x03ff] = data;
  }
 }
 soundPortRead(port) {
  port &= 0xff;
  if (port === 0x10) return this.ay1?.addrLatch ?? 0xff;
  if (port === 0x20) return this.ay1?.readData() ?? 0xff;
  if (port === 0x40) return this.ay2?.addrLatch ?? 0xff;
  if (port === 0x80) return this.ay2?.readData() ?? 0xff;
  return 0xff;
 }
 soundPortWrite(port, data) {
  port &= 0xff;
  data &= 0xff;
  if (port === 0x10) {
   this.ay1?.writeAddr(data);
   return;
  }
  if (port === 0x20) {
   this.ay1?.writeData(data);
   return;
  }
  if (port === 0x40) {
   this.ay2?.writeAddr(data);
   return;
  }
  if (port === 0x80) {
   this.ay2?.writeData(data);
   return;
  }
 }
 runCycles(cpu, budget) {
  let elapsed = 0;
  while (elapsed < budget) elapsed += cpu.step();
  return elapsed;
 }
}

// ── Boot ──────────────────────────────────────────────────
(async () => {
  try {
    const emu = new ScrambleEmu("gameCanvas");
    window.scramble = emu;
    await emu.init();
    await emu.start();
  } catch (err) {
    console.error("Emulator boot failed:", err?.message ?? err, err);
  }
})();