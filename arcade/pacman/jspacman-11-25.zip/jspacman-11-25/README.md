# JSPacman 11.25

A Pen created on CodePen.

Original URL: [https://codepen.io/Subnetpie/pen/LENOQPG](https://codepen.io/Subnetpie/pen/LENOQPG).

