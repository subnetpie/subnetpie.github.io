class jspacman {
 constructor() {
  // Canvas
  this.canvas = document.getElementById("gameCanvas");
  this.ctx = this.canvas.getContext("2d");

  this.ghostWriteCount = 0;
  this.lastFramePC = 0;
  this.accumulator = 0;
  this.lastFrameTime = 0;
  this.targetInterval = 1000 / 60.606; // ~16.5ms per frame
  this.cyclesPerFrame = 50688; 

  // CPU
  this.cpu = new Z80();
  this.cpu.emulator = this;
  this.cpu.memRead = (addr) => this.memoryRead(addr);
  this.cpu.memWrite = (addr, value) => this.memoryWrite(addr, value);
  this.cpu.ioRead = (addr) => this.ioRead(addr);
  this.cpu.ioWrite = (addr, value) => this.ioWrite(addr, value);
  this.cpu.vectorLatch = 0x00;

  // Memory and ROM - Single unified memory array (Bus approach)
  this.memory = new Uint8Array(0x10000); // 64K CPU space
  this.memory.fill(0x00);

  // Decoded graphics
  this.palette = [];
  this.clut = new Uint8Array(256);
  this.chars = [];
  this.sprites = [];

  // Flags
  this.flipScreen = false;
  this.soundEnable = false;
  this.interruptEnable = true;

  // I/O registers array
  this.ioRegisters = new Uint8Array(256);

  // Frame timing
  this.frameCounter = 0;
  this.lastFrameTime = 0;
  this.cyclesThisFrame = 0;
  this.vblankTriggered = false;
  this.vblankFlag = false;

  // Inputs
  this.inputs = {
   up: false,
   down: false,
   left: false,
   right: false,
   coin1: false,
   coin2: false,
   credit: false,
   start1: false,
   start2: false
  };

  // Control state
  this.running = false;
 }

 // ===== ROM LOADING WITH INSTANCE VARIABLES =====
 async loadROMS() {
  const basePath = "https://subnetpie.github.io/pacman/";

  const files = {
   "pacman.6e": { target: "rom", offset: 0x0000 },
   "pacman.6f": { target: "rom", offset: 0x1000 },
   "pacman.6h": { target: "rom", offset: 0x2000 },
   "pacman.6j": { target: "rom", offset: 0x3000 },
   "pacman.5e": { target: "char", offset: 0x0000 },
   "pacman.5f": { target: "sprite", offset: 0x0000 },
   "82s123.7f": { target: "color", offset: 0x0000 },
   "82s126.4a": { target: "palette", offset: 0x0000 }
  };

  this.romData = new Uint8Array(0x4000);
  this.charRom = new Uint8Array(0x1000);
  this.spriteRom = new Uint8Array(0x1000);
  this.colorProm = new Uint8Array(32);
  this.colorTable = new Uint8Array(256);

  const loadRomFile = (url) => {
   return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("GET", url, true);
    xhr.responseType = "arraybuffer";
    xhr.timeout = 10000;
    xhr.onload = () => {
     if (xhr.status >= 200 && xhr.status < 300) {
      resolve(new Uint8Array(xhr.response));
     } else {
      reject(new Error(`HTTP ${xhr.status}: ${xhr.statusText}`));
     }
    };
    xhr.onerror = () => reject(new Error(`Network error loading ${url}`));
    xhr.ontimeout = () => reject(new Error(`Timeout loading ${url}`));
    xhr.onabort = () => reject(new Error(`Request aborted for ${url}`));
    xhr.send();
   });
  };

  await Promise.all(
   Object.entries(files).map(async ([filename, config]) => {
    const data = await loadRomFile(basePath + filename);

    switch (config.target) {
     case "rom":
      this.romData.set(
       data.subarray(0, data.length), // Load full ROM data
       config.offset
      );
      break;
      break;
     case "char":
      this.charRom.set(data.subarray(0, data.length), config.offset);
      break;
     case "sprite":
      this.spriteRom.set(data.subarray(0, data.length), config.offset);
      break;
     case "color":
      this.colorProm.set(data.subarray(0, 256), config.offset);
      break;
     case "palette":
      this.colorTable.set(data.subarray(0, 256), config.offset);
      break;
    }
   })
  );
 }

 // ===== IO BUS ARCHITECTURE =====
 ioRead(port) {
  const offset = port & 0xff;

  if (offset === 0x00) {
   return this.cpu.vectorLatch ?? 0x00;
  }

  if (offset >= 0x60 && offset <= 0x6f) {
   return this.memory[0x5060 + (offset - 0x60)];
  }

  return this.ioRegisters[offset] ?? 0xff;
 }
 ioWrite(port, data) {
  const offset = port & 0xff;
  data &= 0xff;

  if (offset === 0x00) {
   this.cpu.vectorLatch = data;
   return;
  }
 }
 readInputs(addr) {
  const offset = addr & 0xff;
  return this.ioRead(offset);
 }

 // ===== MEMORY ARCHITECTURE =====
 memoryRead(addr) {
  addr &= 0xffff;
  
    
  if (addr >= 0x8000 && addr <= 0x8fff) addr = 0x4000 + (addr & 0x0fff);
  else if (addr >= 0xc000 && addr <= 0xcfff) addr = 0x4000 + (addr & 0x0fff);
  
  
  if (addr < 0x4000) {
   return this.memory[addr];
  }

  if (addr >= 0x5000 && addr < 0x5100) {
   const offset = addr & 0xff;

   if (offset < 0x40) {
    let v = 0xff;
    if (this.inputs.up) v &= ~0x01;
    if (this.inputs.left) v &= ~0x02;
    if (this.inputs.right) v &= ~0x04;
    if (this.inputs.down) v &= ~0x08;
    if (this.inputs.coin1) v &= ~0x20;
    if (this.inputs.coin2) v &= ~0x40;
    if (this.inputs.credit) v &= ~0x80;
    return v;
   }

   if (offset >= 0x40 && offset < 0x80) {
    let v = 0xff;
    if (this.inputs.start1) v &= ~0x20;
    if (this.inputs.start2) v &= ~0x40;
    return v;
   }

   if (offset >= 0x80 && offset < 0xc0) {
    let dsw = 0xff;
    dsw |= 0x01;
    dsw &= ~0x02;
    //    dsw &= ~0x03;
    dsw &= ~0x04;
    dsw |= 0x08;
    dsw &= ~0x30;
    return dsw;
   }

   if (offset >= 0x60 && offset < 0x70) {
    return this.memory[addr];
   }
   return 0xff;
  }
  return this.memory[addr];
 }
 memoryWrite(addr, data) {
  addr &= 0xffff;
  data &= 0xff;

  // Mirroring for Video RAM and Main RAM
  if (addr >= 0x8000 && addr <= 0x8fff) addr = 0x4000 + (addr & 0x0fff);
  else if (addr >= 0xc000 && addr <= 0xcfff) addr = 0x4000 + (addr & 0x0fff);

  // ROM is Read-Only
  if (addr < 0x4000) return;

  // Memory Mapped Registers (0x5000 - 0x5007) - Write Only
  // CRITICAL: These control timing and hardware state
  if (addr >= 0x5000 && addr < 0x5008) {
   this.memory[addr] = data; // Store strictly for debugging
   const bit0 = (data & 0x01) === 0x01;
   
   switch (addr & 0x07) {
    case 0x00: // Interrupt Enable
     this.interruptEnable = bit0; 
     break;
    case 0x01: // Sound Enable
     this.soundEnable = bit0;
     break;
    case 0x02: // Flip Screen (Cocktail Mode)
     this.flipScreen = bit0;
     break;
    // 5003: 1P Start Lamp, 5004: 2P Start Lamp, 5005: Coin Lockout
    // 5006: Coin Counter, 5007: Sound Control
   }
   return;
  }

  // Watchdog Reset (Write to 0x50C0)
  if (addr >= 0x50c0 && addr <= 0x50ff) {
     // Reset watchdog timer here if implementing watchdog
     return;
  }

  this.memory[addr] = data;
 }

 // ===== BUILD ARCHITECTURE =====
 buildPalette(colorProm) {
  const palette = new Array(16);
  for (let i = 0; i < 16; i++) {
   const d = colorProm[i];
   const r =
    (d & 0x01 ? 0x21 : 0) + (d & 0x02 ? 0x47 : 0) + (d & 0x04 ? 0x97 : 0);
   const g =
    (d & 0x08 ? 0x21 : 0) + (d & 0x10 ? 0x47 : 0) + (d & 0x20 ? 0x97 : 0);
   const b = (d & 0x40 ? 0x51 : 0) + (d & 0x80 ? 0xae : 0);
   palette[i] = `rgb(${r},${g},${b})`;
  }
  return palette;
 }
 buildCLUT(colorTable) {
  const clut = new Uint8Array(256);
  for (let i = 0; i < 256; i++) {
   clut[i] = colorTable[i] & 0x0f;
  }
  return clut;
 }
 buildChars(charRom) {
  const chars = new Array(256);

  for (let tileNum = 0; tileNum < 256; tileNum++) {
   const base = tileNum * 16;
   const raw = new Uint8Array(64); // decoded 8×8 pixels
   const pixels = new Uint8Array(64); // transformed tile

   // 1) Decode raw pixels (as before)
   for (let col = 0; col < 8; col++) {
    const lowerByte = charRom[base + col];
    const upperByte = charRom[base + 8 + col];
    for (let rowNib = 0; rowNib < 4; rowNib++) {
     const bitPos = 3 - rowNib;
     // upper half → rows 0–3
     const ub0 = (upperByte >> bitPos) & 1;
     const ub1 = (upperByte >> (bitPos + 4)) & 1;
     raw[rowNib * 8 + col] = (ub1 << 1) | ub0;
     // lower half → rows 4–7
     const lb0 = (lowerByte >> bitPos) & 1;
     const lb1 = (lowerByte >> (bitPos + 4)) & 1;
     raw[(rowNib + 4) * 8 + col] = (lb1 << 1) | lb0;
    }
   }
   for (let y = 0; y < 8; y++) {
    for (let x = 0; x < 8; x++) {
     const srcIndex = y * 8 + x;
     // CCW rotate
     const rx = y;
     const ry = 7 - x;
     // Then vertical flip
     const fy = 7 - ry;
     const dstIndex = fy * 8 + rx;
     pixels[dstIndex] = raw[srcIndex];
    }
   }

   chars[tileNum] = pixels;
  }

  return chars;
 }
 buildSprites(spriteRom) {
  const sprites = new Array(64);

  for (let spriteNum = 0; spriteNum < 64; spriteNum++) {
   const base = spriteNum * 64;
   const raw = new Uint8Array(256); // Temporary buffer
   const pixels = new Uint8Array(256); // 16x16 = 256 pixels

   // Process 8 strips with existing coordinate mapping
   for (let strip = 0; strip < 8; strip++) {
    const stripBase = base + strip * 8;
    let stripY, stripX;
    if (strip === 4) {
     stripY = 0;
     stripX = 8;
    } else if (strip === 0) {
     stripY = 0;
     stripX = 0;
    } else if (strip === 5) {
     stripY = 12;
     stripX = 8;
    } else if (strip === 1) {
     stripY = 12;
     stripX = 0;
    } else if (strip === 6) {
     stripY = 8;
     stripX = 8;
    } else if (strip === 2) {
     stripY = 8;
     stripX = 0;
    } else if (strip === 7) {
     stripY = 4;
     stripX = 8;
    } else if (strip === 3) {
     stripY = 4;
     stripX = 0;
    }

    for (let byteIdx = 0; byteIdx < 8; byteIdx++) {
     const byte = spriteRom[stripBase + byteIdx];

     for (let pixelRow = 0; pixelRow < 4; pixelRow++) {
      const bit0 = (byte >> pixelRow) & 1;
      const bit1 = (byte >> (pixelRow + 4)) & 1;
      const pixelValue = (bit1 << 1) | bit0;
      const x = stripX + byteIdx;
      const y = stripY + pixelRow;
      raw[y * 16 + x] = pixelValue;
     }
    }
   }

   // Apply 90-degree CLOCKWISE rotation: (x, y) -> (15 - y, x)

   for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
     const srcIndex = y * 16 + x;
     const newX = 15 - y;
     const newY = x;
     const dstIndex = newY * 16 + newX;
     pixels[dstIndex] = raw[srcIndex];
    }
   }
   sprites[spriteNum] = pixels;
  }
  return sprites;
 }

 // ===== RENDERING ARCHITECTURE =====
 renderTiles(ctx, memory, chars, palette, clut, flip) {
  for (let off = 0; off < 0x400; off++) {
   const code = memory[0x4000 + off];
   const colorByte = memory[0x4400 + off];

   // Extract the 6-bit color index (bits 0-5 only)
   const col6 = colorByte & 0x3f;
   let sx, sy;
   const row = Math.floor(off / 32);
   const col = off % 32;

   if (off < 0x40) {
    sx = row + 34;
    sy = col - 2;
   } else if (off < 0x3c0) {
    sx = col + 2;
    sy = row - 2;
   } else {
    sx = row - 30;
    sy = col - 2;
   }

   const pix = chars[code];
   if (!pix) continue;

   // Render 8x8 tile
   for (let py = 0; py < 8; py++) {
    for (let px = 0; px < 8; px++) {
     const p = pix[py * 8 + px];
     const clutIndex = (col6 << 2) | p;
     const paletteIndex = clut[clutIndex] & 0x0f;
     if (paletteIndex === 0 && p === 0) continue;
     ctx.fillStyle = palette[paletteIndex];
     ctx.fillRect(sx * 8 + px, sy * 8 + py, 1, 1);
    }
   }
  }
 }
 renderSprites(ctx, memory, sprites, palette, clut, flip) {
  for (let i = 7; i > 0; i--) {

   const attrAddr = 0x4ff0 + i * 2;
   const attrByte = memory[attrAddr];
   const shape = (attrByte >> 2) & 0x3f;

   // Flip flags
   const fx = !!(attrByte & 0x01);
   const fy = !!(attrByte & 0x02);

   // Color lookup table index
   const col6 = memory[attrAddr + 1] & 0x3f;

   // Sprite position address - ROM also updates these
   const posAddr = 0x5060 + i * 2;
   const rawX = memory[posAddr + 1];
   const rawY = memory[posAddr];

   // Apply MAME transformation
   let x = 272 - rawX;
   let y = rawY - 31;

   // Hardware offset hack for first two sprites
   if (i <= 1) {
    y += 1;
   }
   const pix = sprites[shape];
   if (!pix) continue;

   // Screen flip for cocktail mode
   if (flip) {
    x = 224 - 16 - x;
    y = 288 - 16 - y;
   }

   // Render sprite pixels with transparency
   for (let py = 0; py < 16; py++) {
    for (let px = 0; px < 16; px++) {
     const spx = fx ? 15 - px : px;
     const spy = fy ? 15 - py : py;
     const p = pix[spy * 16 + spx];

     // Color lookup: combine color index and pixel value
     const clutIndex = ((col6 | 0x40) << 2) | p;
     const paletteIndex = clut[clutIndex & 0xff] & 0x0f;
     const screenX = x + px;
     const screenY = y + py;

     // Skip transparent pixels
     if (p === 0 || paletteIndex === 0) continue;
     
     if (screenX >= 0 && screenX < 288 && screenY >= 0 && screenY < 224) {
      ctx.fillStyle = palette[paletteIndex];
      ctx.fillRect(screenX, screenY, 1, 1);
     }
    }
   }
  }
 }
 renderFrame() {
  this.ctx.fillStyle = "#000";
  this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
  
  this.renderTiles(
   this.ctx,
   this.memory,
   this.chars,
   this.palette,
   this.clut,
   this.flipScreen
  );

  this.renderSprites(
   this.ctx,
   this.memory,
   this.sprites,
   this.palette,
   this.clut,
   this.flipScreen
  );
 }
 
 // ===== FRAME LOOP WITH FIXED TIMESTEP ACCUMULATOR =====
 frameLoop() {
  if (!this.running) return;

  // Use performance.now() for high precision
  const now = performance.now();
  let delta = now - (this.lastFrameTime || now);
  this.lastFrameTime = now;

  // Prevent runaway if tab is inactive (max 100ms step)
  if (delta > 100) delta = 100;

  // Accumulate elapsed time
  this.accumulator += delta;

  // Execute as many full emulation frames as we have accumulated time
  while (this.accumulator >= this.targetInterval) {
    this.runCpuFrame();          // Executes exactly this.cyclesPerFrame Z80 cycles
    this.accumulator -= this.targetInterval;
    this.frameCounter++;
  }

  // Always render at host refresh rate
  this.renderFrame();

  // Schedule next frame
  requestAnimationFrame(() => this.frameLoop());
}

 // ===== CORE EMULATION STEP =====
 runCpuFrame() {
  let cyclesLeft = this.cyclesPerFrame;

  while (cyclesLeft > 0) {
    const execCycles = this.cpu.step(); // Should return cycles consumed by the instruction
    cyclesLeft -= execCycles;
    // Optional: break if step took too long, but do NOT break for performance reasons
    // -- accumulator solves that cleanly
  }

  // VBlank interrupt at end of frame if enabled
  if (this.interruptEnable) {
    this.cpu.irqPending = true; // Z80 core should handle this on its own
    // IM 1 (RST 38h) or IM 0/2 with vector; set cpu.vectorLatch as appropriate
    // If using IM 1, make sure your core uses 0xFF (RST 38h) during INTA
  }
}
 stopEmulator() {
  if (this.running) {
   this.running = false;
   this.frameLoopActive = false;
   this.updateButtonStates();
  }
 }
 updateButtonStates() {
  const startBtn = document.getElementById("startBtn");
  const stopBtn = document.getElementById("stopBtn");

  if (startBtn && stopBtn) {
   startBtn.disabled = this.running;
   stopBtn.disabled = !this.running;
  }
 }

 // ===== START =====
 async start() {
  this.memory.fill(0x00);
  this.memory.set(this.romData, 0x0000);

  this.palette = this.buildPalette(this.colorProm);
  this.clut = this.buildCLUT(this.colorTable);
  this.chars = this.buildChars(this.charRom);
  this.sprites = this.buildSprites(this.spriteRom);

  this.cpu.reset();

  this.running = true;
  this.frameLoop();
 }
 stop() {
  if (this.running) {
   this.running = false;
   updateButtonStates();
  }
 }
}

// ==========================================
// SWIPE / GESTURE CONTROLLER (Refactored)
// ==========================================
class SwipeController {
    constructor() {
        // Attach to the entire document body to catch swipes anywhere on screen
        // This fixes issues where overlays (headers, score) block the canvas.
        this.element = document.body; 
        this.touchStart = null;
        this.minSwipeDist = 30; // px threshold
        
        this.latchedDirection = null; 

        // Bind events with { passive: false }
        const bind = (evt, fn) => this.element.addEventListener(evt, fn.bind(this), { passive: false });
        bind('touchstart', this.handleStart);
        bind('touchmove', this.handleMove);
        bind('touchend', this.handleEnd);
    }

    handleStart(e) {
        // ALLOW clicks on buttons (Start, Coin, etc.) to pass through
        if (e.target.tagName === 'BUTTON' || e.target.closest('button')) {
            return; 
        }

        e.preventDefault(); // Stop iOS scroll/zoom
        const t = e.changedTouches[0];
        this.touchStart = { x: t.clientX, y: t.clientY };
    }

    handleMove(e) {
        // If we aren't tracking a swipe, let normal events happen
        if (!this.touchStart) return;
        e.preventDefault();
    }

    handleEnd(e) {
        // If we aren't tracking a swipe, let normal events happen
        if (!this.touchStart) return;
        
        e.preventDefault();
        this.detectSwipe(e);
        this.touchStart = null;
    }

    detectSwipe(e) {
        const t = e.changedTouches[0];
        const dx = t.clientX - this.touchStart.x;
        const dy = t.clientY - this.touchStart.y;
        const absX = Math.abs(dx);
        const absY = Math.abs(dy);

        // 1. Check threshold
        if (absX < this.minSwipeDist && absY < this.minSwipeDist) return;

        // 2. Determine dominant axis
        let newDir = null;
        if (absX > absY) {
            newDir = dx > 0 ? 'right' : 'left';
        } else {
            newDir = dy > 0 ? 'down' : 'up';
        }

        // 3. Update Emulator Input
        if (newDir) {
            this.applyInput(newDir);
        }
    }

    applyInput(direction) {
        const emu = window.pacmanEmulator;
        if (!emu || !emu.inputs) return;

        // Latch logic: clear others, hold this one
        emu.inputs.up = false;
        emu.inputs.down = false;
        emu.inputs.left = false;
        emu.inputs.right = false;

        if (direction) {
            emu.inputs[direction] = true;
            this.latchedDirection = direction;
            // console.log(`[Input] Swiped ${direction}`);
        }
    }
}

// Initialize automatically
document.addEventListener('DOMContentLoaded', () => {
    new SwipeController();
    console.log("[INIT] Global Swipe Controller initialized");
});

// ===== D-PAD TOUCH CONTROLS =====
function setupDPadControls() {
 const dpadButtons = document.querySelectorAll('.pad');
 
 dpadButtons.forEach(button => {
  const direction = button.getAttribute('data-dir');
  
  // Handle touch events (mobile)
  button.addEventListener('touchstart', (e) => {
   e.preventDefault();
   if (window.pacmanEmulator) {
    window.pacmanEmulator.inputs[direction] = true;
    button.classList.add('pressed');
   }
  }, { passive: false });
  
  button.addEventListener('touchend', (e) => {
   e.preventDefault();
   if (window.pacmanEmulator) {
    window.pacmanEmulator.inputs[direction] = false;
    button.classList.remove('pressed');
   }
  }, { passive: false });
  
  button.addEventListener('touchcancel', (e) => {
   e.preventDefault();
   if (window.pacmanEmulator) {
    window.pacmanEmulator.inputs[direction] = false;
    button.classList.remove('pressed');
   }
  }, { passive: false });
  
  // Handle mouse events (desktop)
  button.addEventListener('mousedown', (e) => {
   e.preventDefault();
   if (window.pacmanEmulator) {
    window.pacmanEmulator.inputs[direction] = true;
    button.classList.add('pressed');
   }
  });
  
  button.addEventListener('mouseup', (e) => {
   e.preventDefault();
   if (window.pacmanEmulator) {
    window.pacmanEmulator.inputs[direction] = false;
    button.classList.remove('pressed');
   }
  });
  
  button.addEventListener('mouseleave', (e) => {
   if (window.pacmanEmulator) {
    window.pacmanEmulator.inputs[direction] = false;
    button.classList.remove('pressed');
   }
  });
  
  // Prevent context menu on long press
  button.addEventListener('contextmenu', (e) => {
   e.preventDefault();
  });
 });
}

// ===== EVENT HANDLERS =====
document.addEventListener("keydown", (e) => {
 if (!window.pacmanEmulator) return;
 const emu = window.pacmanEmulator;

 // Debug shortcuts
 if (e.key === "F5") {
  e.preventDefault();
  continueFromBreakpoint();
  return;
 }

 if (e.key === "F7") {
  e.preventDefault();
  triggerInterrupt();
  return;
 }

 if (e.key === "F8") {
  e.preventDefault();
  step100CPU();
  return;
 }

 if (e.key === "F9") {
  e.preventDefault();
  resetCPU();
  return;
 }

 if (e.key === "F10") {
  e.preventDefault();
  stepCPU();
  return;
 }

 if (e.key === "F11") {
  e.preventDefault();
  stepAtBreakpoint();
  return;
 }

 // Game controls
 switch (e.key.toLowerCase()) {
  case "arrowup":
  case "w":
   emu.inputs.up = true;
   break;
  case "arrowdown":
  case "s":
   emu.inputs.down = true;
   break;
  case "arrowleft":
  case "a":
   emu.inputs.left = true;
   break;
  case "arrowright":
  case "d":
   emu.inputs.right = true;
   break;
  case "5":
   emu.inputs.coin1 = true;
   break;
  case "6":
   emu.inputs.coin2 = true;
   break;
  case "1":
   emu.inputs.start1 = true;
   break;
  case "2":
   emu.inputs.start2 = true;
   break;
 }
});
document.addEventListener("keyup", (e) => {
 if (!window.pacmanEmulator) return;
 const emu = window.pacmanEmulator;

 switch (e.key.toLowerCase()) {
  case "arrowup":
  case "w":
   emu.inputs.up = false;
   break;
  case "arrowdown":
  case "s":
   emu.inputs.down = false;
   break;
  case "arrowleft":
  case "a":
   emu.inputs.left = false;
   break;
  case "arrowright":
  case "d":
   emu.inputs.right = false;
   break;
  case "5":
   emu.inputs.coin1 = false;
   break;
  case "6":
   emu.inputs.coin2 = false;
   break;
  case "1":
   emu.inputs.start1 = false;
   break;
  case "2":
   emu.inputs.start2 = false;
   break;
 }
});

// ===== KEYBOARD AND BUTTON INPUT =====
document.addEventListener("keydown", (e) => {
 if (!window.pacmanEmulator) return;
 const emu = window.pacmanEmulator;

 switch (e.key.toLowerCase()) {
  case "arrowup":
  case "w":
   emu.inputs.up = true;
   break;
  case "arrowdown":
  case "s":
   emu.inputs.down = true;
   break;
  case "arrowleft":
  case "a":
   emu.inputs.left = true;
   break;
  case "arrowright":
  case "d":
   emu.inputs.right = true;
   break;
  case "5":
   emu.inputs.coin1 = true;
   break;
  case "6":
   emu.inputs.coin2 = true;
   break;
  case "1":
   emu.inputs.start1 = true;
   break;
  case "2":
   emu.inputs.start2 = true;
   break;
 }
});
document.addEventListener("keyup", (e) => {
 if (!window.pacmanEmulator) return;
 const emu = window.pacmanEmulator;

 switch (e.key.toLowerCase()) {
  case "arrowup":
  case "w":
   emu.inputs.up = false;
   break;
  case "arrowdown":
  case "s":
   emu.inputs.down = false;
   break;
  case "arrowleft":
  case "a":
   emu.inputs.left = false;
   break;
  case "arrowright":
  case "d":
   emu.inputs.right = false;
   break;
  case "5":
   emu.inputs.coin1 = false;
   break;
  case "6":
   emu.inputs.coin2 = false;
   break;
  case "1":
   emu.inputs.start1 = false;
   break;
  case "2":
   emu.inputs.start2 = false;
   break;
 }
});
function insertCoin1() {
 if (!window.pacmanEmulator) return;
 window.pacmanEmulator.inputs.coin1 = true;
 setTimeout(() => {
  window.pacmanEmulator.inputs.coin1 = false;
 }, 100);
}
function start1Player() {
 if (!window.pacmanEmulator) return;
 window.pacmanEmulator.inputs.start1 = true;
 setTimeout(() => {
  window.pacmanEmulator.inputs.start1 = false;
 }, 100);
}
async function startEmulator() {
 try {
  console.log("[INIT] Starting Pac-Man emulator...");
  const emu = new jspacman();
  
  await emu.loadROMS();
  emu.start();
  window.pacmanEmulator = emu;
  
  console.log("[INIT] Emulator started successfully");
  updateButtonStates();
 } catch (error) {
  console.error("[ERROR] Failed to start emulator:", error);
  alert("Failed to start emulator: " + error.message);
 }
}
function updateButtonStates() {
 const toggleBtn = document.getElementById("toggleBtn");
 const resetBtn = document.getElementById("resetBtn");
 if (toggleBtn) {
  toggleBtn.textContent = window.pacmanEmulator && window.pacmanEmulator.running ? "Stop" : "Start";
  toggleBtn.disabled = false;
 }
 if (resetBtn) {
  resetBtn.disabled = false; // Reset is always available
 }
}
function stopEmulator() {
 if (window.pacmanEmulator) {
  window.pacmanEmulator.stop();
  updateButtonStates();
 }
}
function toggleEmulator() {
 // If emulator exists and is running, stop it
 if (window.pacmanEmulator && window.pacmanEmulator.running) {
  stopEmulator();
 } else {
  // Otherwise, start it (will create new instance if needed)
  startEmulator();
 }
}
function updateButtonStates() {
 const toggleBtn = document.getElementById("toggleBtn");
 const resetBtn = document.getElementById("resetBtn");

 if (toggleBtn) {
  toggleBtn.textContent = window.pacmanEmulator && window.pacmanEmulator.running ? "Stop" : "Start";
  toggleBtn.disabled = false;
 }
 
 if (resetBtn) {
  resetBtn.disabled = false; // Reset is always available
 }
}

window.addEventListener("DOMContentLoaded", startEmulator);
setupDPadControls();

