//===========================================================
// MS. PAC-MAN EMULATOR - BOOTLEG REFACTOR (NO AUX BOARD)
//===========================================================
// Uses decrypted bootleg ROMs to bypass the custom Z80
// daughterboard protection. This runs on Pac-Man hardware.
//===========================================================
class jsMsPacMan {
 constructor() {
  this.canvas = document.getElementById("gameCanvas");
  this.ctx = this.canvas.getContext("2d");

  this.accumulator = 0;
  this.lastFrameTime = 0;
  this.targetInterval = 1000 / 60.606;
  this.cyclesPerFrame = 50688; // 3.072 MHz / 60.606 Hz

  this.memory = new Uint8Array(0x10000);

  this.cpu = new Z80();
  this.cpu.emulator = this;
  // Standard simple read/fetch without trap logic
  this.cpu.memRead = (addr) => this.memoryRead(addr);
  this.cpu.fetchOpcode = (addr) => this.memoryRead(addr);
  this.cpu.memWrite = this.memoryWrite.bind(this);
  this.cpu.ioRead = this.ioRead.bind(this);
  this.cpu.ioWrite = this.ioWrite.bind(this);
  this.cpu.vectorLatch = 0x00;

  // Graphics & Audio
  this.palette = [];
  this.clut = new Uint8Array(256);
  this.chars = [];
  this.sprites = [];

  this.charRom = new Uint8Array(0x1000);
  this.spriteRom = new Uint8Array(0x1000);
  this.colorProm = new Uint8Array(32);
  this.colorTable = new Uint8Array(256);

  // IO / State
  this.ioRegisters = new Uint8Array(256);
  this.flipScreen = false;
  this.soundEnable = false;
  this.interruptEnable = true;
  this.frameCounter = 0;
  this.running = false;

  this.inputs = {
   up: false,
   down: false,
   left: false,
   right: false,
   coin1: false,
   coin2: false,
   credit: false,
   start1: false,
   start2: false
  };
 }
 async loadROMS() {
  const basePath = "https://subnetpie.github.io/mspacman/";

  console.log(`Loading Ms. Pac-Man Bootleg ROMs from ${basePath}...`);

  // BOOTLEG MAPPING (mspacmab):
  // boot1 -> 0x0000 (Code)
  // boot2 -> 0x1000 (Code)
  // boot3 -> 0x2000 (Code)
  // boot4 -> 0x3000 (Code)
  // boot5 -> 0x8000 (Extra Code)
  // boot6 -> 0x9000 (Extra Code)
  // Graphics and PROMs remain standard.
        
        const files = {
           // Main Program (Bootleg Decrypted + Fast Speed Hack)
           "boot1": { target: "rom", offset: 0x0000 },
           "boot2": { target: "rom", offset: 0x1000 }, // Fast ROM loaded here
               //     "pacfast.6f": { target: "rom", offset: 0x1000 }, // Fast ROM loaded here
           "boot3": { target: "rom", offset: 0x2000 },
           "boot4": { target: "rom", offset: 0x3000 },
           "boot5": { target: "rom", offset: 0x8000 },
           "boot6": { target: "rom", offset: 0x9000 },

           // Graphics (Standard Ms. Pac-Man)
           "5e": { target: "char", offset: 0x0000 },
           "5f": { target: "sprite", offset: 0x0000 },
           
           // PROMs
           "82s123.7f": { target: "color", offset: 0x0000 },
           "82s126.4a": { target: "palette", offset: 0x0000 }
        };

  const loadRomFile = (url) => {
   return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("GET", url, true);
    xhr.responseType = "arraybuffer";
    xhr.onload = () => {
     if (xhr.status >= 200 && xhr.status < 300) {
      resolve(new Uint8Array(xhr.response));
     } else {
      console.warn(`Missing file: ${url} (Status: ${xhr.status})`);
      // Return empty 4k buffer if missing to prevent crash, but warn
      resolve(new Uint8Array(0x1000));
     }
    };
    xhr.onerror = () => reject(`Network error loading ${url}`);
    xhr.send();
   });
  };

  await Promise.all(
   Object.entries(files).map(async ([filename, config]) => {
    try {
     const data = await loadRomFile(basePath + filename);
     switch (config.target) {
      case "rom":
       this.memory.set(data, config.offset);
       break;
      case "char":
       this.charRom.set(data, config.offset);
       break;
      case "sprite":
       this.spriteRom.set(data, config.offset);
       break;
      case "color":
       this.colorProm.set(data.subarray(0, 32), config.offset);
       break;
      case "palette":
       this.colorTable.set(data.subarray(0, 256), config.offset);
       break;
     }
    } catch (err) {
     console.error(err);
    }
   })
  );

  console.log("✓ Bootleg ROMs Loaded.");
 }
 //===========================================================
// MEMORY & IO - SIMPLIFIED (NO TRAPS)
//===========================================================
 memoryRead(addr) {
  addr &= 0xffff;

  // ROM / RAM Mirrors
  if (addr < 0x4000) return this.memory[addr]; // Main ROM
  if (addr >= 0x4000 && addr <= 0x4fff) return this.memory[addr]; // Video/Color RAM

  // IO Ports / Registers
  if (addr >= 0x5000 && addr < 0x5100) {
   const offset = addr & 0xff;

   // IN0 (Joystick / Coin)
   if (offset < 0x40) {
    let v = 0xff;
    if (this.inputs.up) v &= ~0x01;
    if (this.inputs.left) v &= ~0x02;
    if (this.inputs.right) v &= ~0x04;
    if (this.inputs.down) v &= ~0x08;
    if (this.inputs.coin1) v &= ~0x20;
    if (this.inputs.coin2) v &= ~0x40;
    if (this.inputs.credit) v &= ~0x80;
    return v;
   }

   // IN1 (Start Buttons)
   if (offset >= 0x40 && offset < 0x80) {
    let v = 0xff;
    if (this.inputs.start1) v &= ~0x20;
    if (this.inputs.start2) v &= ~0x40;
    // Cabinet dip switches etc can be added here
    return v;
   }

   // DSW1 (Dip Switches)
   if (offset >= 0x80 && offset < 0xc0) {
    // Racks/Difficulty settings
    return 0b11001001;
   }
   return 0xff;
  }

  // Extra Bootleg ROM Area
  if (addr >= 0x8000 && addr <= 0x9fff) return this.memory[addr];

  // Default catch-all (RAM mirrors etc)
  return this.memory[addr];
 }
 memoryWrite(addr, data) {
  addr &= 0xffff;
  data &= 0xff;

  // *** MIRRORING FIX (Crucial for Stack & RAM variables) ***
  // Mirrors 0xC000-0xCFFF back to 0x4000-0x4FFF
  if (addr >= 0xc000 && addr <= 0xcfff) {
    addr = 0x4000 + (addr & 0x0fff);
  }

  // ROM Protection
  // Blocks writes to Main ROM (0-3FFF) and Ms. Pac Aux ROM (8000-9FFF)
  if (addr < 0x4000 || (addr >= 0x8000 && addr <= 0x9fff)) return;

  // Video / Color / Work RAM (Now handles 0xC000 mirrors via remapping above)
  if (addr >= 0x4000 && addr <= 0x4fff) {
   this.memory[addr] = data;
   return;
  }

  // IO Handling
  if (addr >= 0x5000) {
   // Interrupt / Sound enable / Flip Screen
   if (addr < 0x5008) {
    this.memory[addr] = data;
    const bit0 = (data & 0x01) === 0x01;
    switch (addr & 0x07) {
     case 0x00:
      this.interruptEnable = bit0;
      break;
     case 0x01:
      this.soundEnable = bit0; // Mutes/Unmutes sound
      break;
     case 0x02:
       // Auxiliary board control (Ms. Pac-Man specific)
       // Often written as 0x01 to enable the aux Z80 modification
       break;
     case 0x03:
      this.flipScreen = bit0;
      break;
    }
    return;
   }
   
   // Sound Registers (Voice Waveforms/Frequency)
   // Range: 0x5040 - 0x505F
   if (addr >= 0x5040 && addr <= 0x505f) {
     // TODO: Pass 'data' to your Audio/Sound chip emulator
     this.memory[addr] = data; 
     return;
   }

   // Sprite Coordinates
   if (addr >= 0x5060 && addr <= 0x506f) {
    this.memory[addr] = data;
    return;
   }

   // Watchdog (0x50C0) - Safe to ignore in emulation
   if (addr >= 0x50c0 && addr <= 0x50ff) return;
  }
}
 ioRead(port) {
  // Standard Z80 IM2 Vector Handling
  const offset = port & 0xff;
  if (offset === 0x00) {
   // Return the vector latch if set (usually 0xF8 or similar)
   return this.cpu.vectorLatch ?? 0x00;
  }
  return this.ioRegisters[offset] ?? 0xff;
 }
 ioWrite(port, data) {
  const offset = port & 0xff;
  data &= 0xff;
  if (offset === 0x00) {
   this.cpu.vectorLatch = data;
   return;
  }
  this.ioRegisters[offset] = data;
 }
 //===========================================================
// GRAPHICS PIPELINE
//===========================================================
 buildPalette(colorProm) {
  const palette = new Array(32);
  for (let i = 0; i < 32; i++) {
   const d = colorProm[i];
   // Weights: R (bits 0-2), G (bits 3-5), B (bits 6-7)
   const r =
    (d & 0x01 ? 0x21 : 0) + (d & 0x02 ? 0x47 : 0) + (d & 0x04 ? 0x97 : 0);
   const g =
    (d & 0x08 ? 0x21 : 0) + (d & 0x10 ? 0x47 : 0) + (d & 0x20 ? 0x97 : 0);
   const b = (d & 0x40 ? 0x51 : 0) + (d & 0x80 ? 0xae : 0);
   palette[i] = `rgb(${r},${g},${b})`;
  }
  return palette;
 }
 buildCLUT(colorTable) {
  const clut = new Uint8Array(256);
  for (let i = 0; i < 256; i++) {
   clut[i] = colorTable[i] & 0x0f;
  }
  return clut;
 }
 buildChars(charRom) {
  const chars = new Array(256);
  for (let tileNum = 0; tileNum < 256; tileNum++) {
   const base = tileNum * 16;
   const raw = new Uint8Array(64);
   const pixels = new Uint8Array(64);

   for (let col = 0; col < 8; col++) {
    const lowerByte = charRom[base + col];
    const upperByte = charRom[base + 8 + col];
    for (let rowNib = 0; rowNib < 4; rowNib++) {
     const bitPos = 3 - rowNib;
     const ub0 = (upperByte >> bitPos) & 1;
     const ub1 = (upperByte >> (bitPos + 4)) & 1;
     raw[rowNib * 8 + col] = (ub1 << 1) | ub0;

     const lb0 = (lowerByte >> bitPos) & 1;
     const lb1 = (lowerByte >> (bitPos + 4)) & 1;
     raw[(rowNib + 4) * 8 + col] = (lb1 << 1) | lb0;
    }
   }
   // Rotate/Flip for display
   for (let y = 0; y < 8; y++) {
    for (let x = 0; x < 8; x++) {
     const srcIndex = y * 8 + x;
     const rx = y;
     const ry = 7 - x;
     const fy = 7 - ry; // Rotation math
     const dstIndex = fy * 8 + rx;
     pixels[dstIndex] = raw[srcIndex];
    }
   }
   chars[tileNum] = pixels;
  }
  return chars;
 }
 buildSprites(spriteRom) {
  const sprites = new Array(64);
  for (let spriteNum = 0; spriteNum < 64; spriteNum++) {
   const base = spriteNum * 64;
   const raw = new Uint8Array(256);
   const pixels = new Uint8Array(256);

   for (let strip = 0; strip < 8; strip++) {
    const stripBase = base + strip * 8;
    let stripY, stripX;
    // Sprite layout mapping
    if (strip === 4) {
     stripY = 0;
     stripX = 8;
    } else if (strip === 0) {
     stripY = 0;
     stripX = 0;
    } else if (strip === 5) {
     stripY = 12;
     stripX = 8;
    } else if (strip === 1) {
     stripY = 12;
     stripX = 0;
    } else if (strip === 6) {
     stripY = 8;
     stripX = 8;
    } else if (strip === 2) {
     stripY = 8;
     stripX = 0;
    } else if (strip === 7) {
     stripY = 4;
     stripX = 8;
    } else if (strip === 3) {
     stripY = 4;
     stripX = 0;
    }

    for (let byteIdx = 0; byteIdx < 8; byteIdx++) {
     const byte = spriteRom[stripBase + byteIdx];
     for (let pixelRow = 0; pixelRow < 4; pixelRow++) {
      const bit0 = (byte >> pixelRow) & 1;
      const bit1 = (byte >> (pixelRow + 4)) & 1;
      const pixelValue = (bit1 << 1) | bit0;
      const x = stripX + byteIdx;
      const y = stripY + pixelRow;
      raw[y * 16 + x] = pixelValue;
     }
    }
   }
   // Rotate for display
   for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
     const srcIndex = y * 16 + x;
     const newX = 15 - y;
     const newY = x;
     const dstIndex = newY * 16 + newX;
     pixels[dstIndex] = raw[srcIndex];
    }
   }
   sprites[spriteNum] = pixels;
  }
  return sprites;
 }
 renderTiles(ctx, memory, chars, palette, clut, flip) {
  for (let off = 0; off < 0x400; off++) {
   const code = memory[0x4000 + off];
   const colorByte = memory[0x4400 + off];
   const col6 = colorByte & 0x3f;

   let sx, sy;
   const row = Math.floor(off / 32);
   const col = off % 32;

   // Standard Pac-Man tilemap layout
   if (off < 0x40) {
    sx = row + 34;
    sy = col - 2;
   } // Top 2 rows
   else if (off < 0x3c0) {
    sx = col + 2;
    sy = row - 2;
   } // Middle
   else {
    sx = row - 30;
    sy = col - 2;
   } // Bottom 2 rows

   const pix = chars[code];
   if (!pix) continue;

   for (let py = 0; py < 8; py++) {
    for (let px = 0; px < 8; px++) {
     const p = pix[py * 8 + px];
     const clutIndex = (col6 << 2) | p;
     const paletteIndex = clut[clutIndex] & 0x0f;
     if (paletteIndex === 0 && p === 0) continue; // Transparent

     ctx.fillStyle = palette[paletteIndex];
     ctx.fillRect(sx * 8 + px, sy * 8 + py, 1, 1);
    }
   }
  }
 }
 renderSprites(ctx, memory, sprites, palette, clut, flip) {
  for (let i = 7; i >= 0; i--) {
   const attrAddr = 0x4ff0 + i * 2;
   const attrByte = memory[attrAddr];

   const shape = (attrByte >> 2) & 0x3f;
   const fx = !!(attrByte & 0x01);
   const fy = !!(attrByte & 0x02);

   const col6 = memory[attrAddr + 1] & 0x3f;

   // Coordinates are often mirrored at 0x5060.
   // If we only write to RAM 0x4000-0x4FFF, we might need to look there.
   // But standard code writes to 0x5060.
   // Let's check 0x5060 range in memory.
   const posAddr = 0x5060 + i * 2;
   const rawX = memory[posAddr + 1];
   const rawY = memory[posAddr];

   let x = 272 - rawX;
   let y = rawY - 31;

   // Offset fix for sprite 0/1 if needed (often different in different bootlegs)
   if (i <= 1) y += 1;

   const pix = sprites[shape];
   if (!pix) continue;

   if (flip) {
    x = 224 - 16 - x;
    y = 288 - 16 - y;
   }

   for (let py = 0; py < 16; py++) {
    for (let px = 0; px < 16; px++) {
     const spx = fx ? 15 - px : px;
     const spy = fy ? 15 - py : py;
     const p = pix[spy * 16 + spx];

     const clutIndex = ((col6 | 0x40) << 2) | p;
     // | 0x40 because sprites use the upper part of CLUT

     const paletteIndex = clut[clutIndex & 0xff] & 0x0f;

     const screenX = x + px;
     const screenY = y + py;

     if (p === 0 || paletteIndex === 0) continue;

     if (screenX >= 0 && screenX < 288 && screenY >= 0 && screenY < 224) {
      ctx.fillStyle = palette[paletteIndex];
      ctx.fillRect(screenX, screenY, 1, 1);
     }
    }
   }
  }
 }
 renderFrame() {
  this.ctx.fillStyle = "#000";
  this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
  this.renderTiles(
   this.ctx,
   this.memory,
   this.chars,
   this.palette,
   this.clut,
   this.flipScreen
  );
  this.renderSprites(
   this.ctx,
   this.memory,
   this.sprites,
   this.palette,
   this.clut,
   this.flipScreen
  );
 }
 frameLoop() {
  if (!this.running) return;

  const now = performance.now();
  let delta = now - this.lastFrameTime;
  if (delta > 100) delta = 100;
  this.lastFrameTime = now;
  this.accumulator += delta;

  while (this.accumulator >= this.targetInterval) {
   let cycles = this.cyclesPerFrame;
   while (cycles > 0) {
    cycles -= this.cpu.step();
   }

   // Fire VBLANK Interrupt (IM2)
   if (this.interruptEnable) {
    this.cpu.irqPending = true;
    // Ms. Pac-Man usually uses vector 0xF8 or similar depending on the board
    // But standard Pac-Man uses vector stored in latch.
    // 0x3F is common for Mame, but the game code sets I register.
    // We use the latch value written by the game.
    // If the game hasn't written it, default is often valid.
   }
   this.accumulator -= this.targetInterval;
  }

  this.renderFrame();
  requestAnimationFrame(() => this.frameLoop());
 }

 async start() {
  await this.loadROMS();

  this.palette = this.buildPalette(this.colorProm);
  this.clut = this.buildCLUT(this.colorTable);
  this.chars = this.buildChars(this.charRom);
  this.sprites = this.buildSprites(this.spriteRom);

  this.cpu.reset();

  this.running = true;
  this.lastFrameTime = performance.now();
  this.frameLoop();
  console.log("✓ Ms. Pac-Man started (Bootleg Mode).");
 }
 stop() {
  this.running = false;
 }
}

//===========================================================
// INPUT CONTROLLERS (SWIPE & KEYS) - Unchanged
//===========================================================
class SwipeController {
 constructor() {
  this.element = document.body;
  this.touchStart = null;
  this.minSwipeDist = 30;
  this.latchedDirection = null;

  const bind = (evt, fn) =>
   this.element.addEventListener(evt, fn.bind(this), { passive: false });
  bind("touchstart", this.handleStart);
  bind("touchmove", this.handleMove);
  bind("touchend", this.handleEnd);
 }

 handleStart(e) {
  if (e.target.tagName === "BUTTON" || e.target.closest("button")) return;
  e.preventDefault();
  const t = e.changedTouches[0];
  this.touchStart = { x: t.clientX, y: t.clientY };
 }

 handleMove(e) {
  if (!this.touchStart) return;
  e.preventDefault();
 }

 handleEnd(e) {
  if (!this.touchStart) return;
  e.preventDefault();
  this.detectSwipe(e);
  this.touchStart = null;
 }

 detectSwipe(e) {
  const t = e.changedTouches[0];
  const dx = t.clientX - this.touchStart.x;
  const dy = t.clientY - this.touchStart.y;
  const absX = Math.abs(dx);
  const absY = Math.abs(dy);

  if (absX < this.minSwipeDist && absY < this.minSwipeDist) return;

  let newDir = null;
  if (absX > absY) {
   newDir = dx > 0 ? "right" : "left";
  } else {
   newDir = dy > 0 ? "down" : "up";
  }

  if (newDir) this.applyInput(newDir);
 }

 applyInput(direction) {
  const emu = window.pacmanEmulator;
  if (!emu || !emu.inputs) return;

  emu.inputs.up = false;
  emu.inputs.down = false;
  emu.inputs.left = false;
  emu.inputs.right = false;

  if (direction) {
   emu.inputs[direction] = true;
   this.latchedDirection = direction;
  }
 }
}
document.addEventListener("DOMContentLoaded", () => {
 new SwipeController();
 console.log("✓ Global Swipe Controller initialized");
});
function setupDPadControls() {
 const dpadButtons = document.querySelectorAll(".pad");
 dpadButtons.forEach((button) => {
  const direction = button.getAttribute("data-dir");
  const setInput = (state) => {
   if (window.pacmanEmulator) window.pacmanEmulator.inputs[direction] = state;
  };

  button.addEventListener(
   "touchstart",
   (e) => {
    e.preventDefault();
    setInput(true);
    button.classList.add("pressed");
   },
   { passive: false }
  );
  button.addEventListener(
   "touchend",
   (e) => {
    e.preventDefault();
    setInput(false);
    button.classList.remove("pressed");
   },
   { passive: false }
  );
  button.addEventListener("mousedown", (e) => {
   e.preventDefault();
   setInput(true);
   button.classList.add("pressed");
  });
  button.addEventListener("mouseup", (e) => {
   e.preventDefault();
   setInput(false);
   button.classList.remove("pressed");
  });
  button.addEventListener("mouseleave", (e) => {
   setInput(false);
   button.classList.remove("pressed");
  });
 });
}
function insertCoin1() {
 if (!window.pacmanEmulator) return;
 window.pacmanEmulator.inputs.coin1 = true;
 setTimeout(() => {
  window.pacmanEmulator.inputs.coin1 = false;
 }, 100);
}
function start1Player() {
 if (!window.pacmanEmulator) return;
 window.pacmanEmulator.inputs.start1 = true;
 setTimeout(() => {
  window.pacmanEmulator.inputs.start1 = false;
 }, 100);
}
document.addEventListener("keydown", (e) => {
 if (!window.pacmanEmulator) return;
 const emu = window.pacmanEmulator;
 switch (e.key.toLowerCase()) {
  case "arrowup":
  case "w":
   emu.inputs.up = true;
   break;
  case "arrowdown":
  case "s":
   emu.inputs.down = true;
   break;
  case "arrowleft":
  case "a":
   emu.inputs.left = true;
   break;
  case "arrowright":
  case "d":
   emu.inputs.right = true;
   break;
  case "5":
   emu.inputs.coin1 = true;
   break;
  case "6":
   emu.inputs.coin2 = true;
   break;
  case "1":
   emu.inputs.start1 = true;
   break;
  case "2":
   emu.inputs.start2 = true;
   break;
 }
});
document.addEventListener("keyup", (e) => {
 if (!window.pacmanEmulator) return;
 const emu = window.pacmanEmulator;
 switch (e.key.toLowerCase()) {
  case "arrowup":
  case "w":
   emu.inputs.up = false;
   break;
  case "arrowdown":
  case "s":
   emu.inputs.down = false;
   break;
  case "arrowleft":
  case "a":
   emu.inputs.left = false;
   break;
  case "arrowright":
  case "d":
   emu.inputs.right = false;
   break;
  case "5":
   emu.inputs.coin1 = false;
   break;
  case "6":
   emu.inputs.coin2 = false;
   break;
  case "1":
   emu.inputs.start1 = false;
   break;
  case "2":
   emu.inputs.start2 = false;
   break;
 }
});
async function startEmulator() {
 try {
  console.log("✓ Starting Ms. Pac-Man emulator (Bootleg Refactor)...");
  const emu = new jsMsPacMan();
  await emu.start();
  window.pacmanEmulator = emu;
  console.log("✓ Emulator running successfully!");
 } catch (error) {
  console.error("✗ Failed to start emulator:", error);
  alert("Failed to start emulator: " + error.message);
 }
}
window.addEventListener("DOMContentLoaded", () => {
 startEmulator();
 setupDPadControls();
});
